-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: kolab
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `group_types`
--

DROP TABLE IF EXISTS `group_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `attributes` longtext NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_types`
--

LOCK TABLES `group_types` WRITE;
/*!40000 ALTER TABLE `group_types` DISABLE KEYS */;
INSERT INTO `group_types` VALUES (1,'kolab','Kolab Distribution Group (Static)','A static Kolab Distribution Group (with mail address)','{\"auto_form_fields\":{\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"groupofuniquenames\",\"kolabgroupofuniquenames\"]},\"form_fields\":{\"cn\":[],\"kolaballowsmtprecipient\":{\"type\":\"list\",\"optional\":true},\"kolaballowsmtpsender\":{\"type\":\"list\",\"optional\":true},\"ou\":{\"type\":\"select\"},\"uniquemember\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(2,'kolab_dynamic','Kolab Distribution Group (Dynamic)','A dynamic Kolab Distribution Group (with mail address)','{\"auto_form_fields\":{\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"groupofurls\",\"kolabgroupofuniquenames\"]},\"form_fields\":{\"cn\":[],\"kolaballowsmtprecipient\":{\"type\":\"list\",\"optional\":true},\"kolaballowsmtpsender\":{\"type\":\"list\",\"optional\":true},\"memberurl\":{\"type\":\"ldap_url\",\"optional\":true},\"ou\":{\"type\":\"select\"},\"uniquemember\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(3,'posix','(Pure) POSIX Group','A pure UNIX POSIX Group','{\"auto_form_fields\":{\"gidnumber\":[]},\"fields\":{\"objectclass\":[\"top\",\"groupofuniquenames\",\"posixgroup\"]},\"form_fields\":{\"cn\":[],\"ou\":{\"type\":\"select\"},\"uniquemember\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(4,'posix_mail','Mail-enabled POSIX Group','A Kolab and also UNIX POSIX Group','{\"auto_form_fields\":{\"gidnumber\":[],\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"groupofuniquenames\",\"kolabgroupofuniquenames\",\"posixgroup\"]},\"form_fields\":{\"cn\":[],\"kolaballowsmtprecipient\":{\"type\":\"list\",\"optional\":true},\"kolaballowsmtpsender\":{\"type\":\"list\",\"optional\":true},\"mail\":{\"optional\":true},\"ou\":{\"type\":\"select\"},\"uniquemember\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(5,'simple','Simple Group (Static)','A simple, traditional LDAP group with a static list of members','{\"auto_form_fields\":[],\"fields\":{\"objectclass\":[\"top\",\"groupofuniquenames\"]},\"form_fields\":{\"cn\":[],\"ou\":{\"type\":\"select\"},\"uniquemember\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0);
/*!40000 ALTER TABLE `group_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `options` (
  `attribute` varchar(128) NOT NULL,
  `option_values` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `options`
--

LOCK TABLES `options` WRITE;
/*!40000 ALTER TABLE `options` DISABLE KEYS */;
INSERT INTO `options` VALUES ('preferredlanguage','[\"aa_DJ\",\"aa_ER\",\"aa_ET\",\"af_ZA\",\"am_ET\",\"an_ES\",\"ar_AE\",\"ar_BH\",\"ar_DZ\",\"ar_EG\",\"ar_IN\",\"ar_IQ\",\"ar_JO\",\"ar_KW\",\"ar_LB\",\"ar_LY\",\"ar_MA\",\"ar_OM\",\"ar_QA\",\"ar_SA\",\"ar_SD\",\"ar_SY\",\"ar_TN\",\"ar_YE\",\"as_IN\",\"az_AZ\",\"be_BY\",\"bg_BG\",\"bn_BD\",\"bn_IN\",\"bokmal\",\"br_FR\",\"bs_BA\",\"byn_ER\",\"C\",\"ca_AD\",\"ca_ES\",\"ca_FR\",\"ca_IT\",\"catalan\",\"croatian\",\"csb_PL\",\"cs_CZ\",\"cy_GB\",\"czech\",\"da_DK\",\"danish\",\"dansk\",\"de_AT\",\"de_BE\",\"de_CH\",\"de_DE\",\"de_LU\",\"deutsch\",\"dutch\",\"dz_BT\",\"eesti\",\"el_CY\",\"el_GR\",\"en_AU\",\"en_BW\",\"en_CA\",\"en_DK\",\"en_GB\",\"en_HK\",\"en_IE\",\"en_IN\",\"en_NZ\",\"en_PH\",\"en_SG\",\"en_US\",\"en_ZA\",\"en_ZW\",\"es_AR\",\"es_BO\",\"es_CL\",\"es_CO\",\"es_CR\",\"es_DO\",\"es_EC\",\"es_ES\",\"es_GT\",\"es_HN\",\"es_MX\",\"es_NI\",\"es_PA\",\"es_PE\",\"es_PR\",\"es_PY\",\"es_SV\",\"estonian\",\"es_US\",\"es_UY\",\"es_VE\",\"et_EE\",\"eu_ES\",\"fa_IR\",\"fi_FI\",\"finnish\",\"fo_FO\",\"fr_BE\",\"fr_CA\",\"fr_CH\",\"french\",\"fr_FR\",\"fr_LU\",\"fy_NL\",\"ga_IE\",\"galego\",\"galician\",\"gd_GB\",\"german\",\"gez_ER\",\"gez_ET\",\"gl_ES\",\"greek\",\"gu_IN\",\"gv_GB\",\"hebrew\",\"he_IL\",\"hi_IN\",\"hr_HR\",\"hrvatski\",\"hsb_DE\",\"hu_HU\",\"hungarian\",\"hy_AM\",\"icelandic\",\"id_ID\",\"is_IS\",\"italian\",\"it_CH\",\"it_IT\",\"iw_IL\",\"ja_JP\",\"japanese\",\"ka_GE\",\"kk_KZ\",\"kl_GL\",\"km_KH\",\"kn_IN\",\"ko_KR\",\"korean\",\"ku_TR\",\"kw_GB\",\"ky_KG\",\"lg_UG\",\"lithuanian\",\"lo_LA\",\"lt_LT\",\"lv_LV\",\"mai_IN\",\"mg_MG\",\"mi_NZ\",\"mk_MK\",\"ml_IN\",\"mn_MN\",\"mr_IN\",\"ms_MY\",\"mt_MT\",\"nb_NO\",\"ne_NP\",\"nl_BE\",\"nl_NL\",\"nn_NO\",\"no_NO\",\"norwegian\",\"nr_ZA\",\"nso_ZA\",\"nynorsk\",\"oc_FR\",\"om_ET\",\"om_KE\",\"or_IN\",\"pa_IN\",\"pa_PK\",\"pl_PL\",\"polish\",\"portuguese\",\"POSIX\",\"pt_BR\",\"pt_PT\",\"romanian\",\"ro_RO\",\"ru_RU\",\"russian\",\"ru_UA\",\"rw_RW\",\"se_NO\",\"sid_ET\",\"si_LK\",\"sk_SK\",\"slovak\",\"slovene\",\"slovenian\",\"sl_SI\",\"so_DJ\",\"so_ET\",\"so_KE\",\"so_SO\",\"spanish\",\"sq_AL\",\"sr_CS\",\"sr_ME\",\"sr_RS\",\"ss_ZA\",\"st_ZA\",\"sv_FI\",\"sv_SE\",\"swedish\",\"ta_IN\",\"te_IN\",\"tg_TJ\",\"thai\",\"th_TH\",\"ti_ER\",\"ti_ET\",\"tig_ER\",\"tl_PH\",\"tn_ZA\",\"tr_CY\",\"tr_TR\",\"ts_ZA\",\"tt_RU\",\"turkish\",\"uk_UA\",\"ur_PK\",\"uz_UZ\",\"ve_ZA\",\"vi_VN\",\"wa_BE\",\"xh_ZA\",\"yi_US\",\"zh_CN\",\"zh_HK\",\"zh_SG\",\"zh_TW\",\"zu_ZA\"]'),('c','[\"AD\",\"AE\",\"AF\",\"AG\",\"AI\",\"AL\",\"AM\",\"AO\",\"AQ\",\"AR\",\"AS\",\"AT\",\"AU\",\"AW\",\"AX\",\"AZ\",\"BA\",\"BB\",\"BD\",\"BE\",\"BF\",\"BG\",\"BH\",\"BI\",\"BJ\",\"BL\",\"BM\",\"BN\",\"BO\",\"BQ\",\"BR\",\"BS\",\"BT\",\"BV\",\"BW\",\"BY\",\"BZ\",\"CA\",\"CC\",\"CD\",\"CF\",\"CG\",\"CH\",\"CI\",\"CK\",\"CL\",\"CM\",\"CN\",\"CO\",\"CR\",\"CU\",\"CV\",\"CW\",\"CX\",\"CY\",\"CZ\",\"DE\",\"DJ\",\"DK\",\"DM\",\"DO\",\"DZ\",\"EC\",\"EE\",\"EG\",\"EH\",\"ER\",\"ES\",\"ET\",\"FI\",\"FJ\",\"FK\",\"FM\",\"FO\",\"FR\",\"GA\",\"GB\",\"GD\",\"GE\",\"GF\",\"GG\",\"GH\",\"GI\",\"GL\",\"GM\",\"GN\",\"GP\",\"GQ\",\"GR\",\"GS\",\"GT\",\"GU\",\"GW\",\"GY\",\"HK\",\"HM\",\"HN\",\"HR\",\"HT\",\"HU\",\"ID\",\"IE\",\"IL\",\"IM\",\"IN\",\"IO\",\"IQ\",\"IR\",\"IS\",\"IT\",\"JE\",\"JM\",\"JO\",\"JP\",\"KE\",\"KG\",\"KH\",\"KI\",\"KM\",\"KN\",\"KP\",\"KR\",\"KW\",\"KY\",\"KZ\",\"LA\",\"LB\",\"LC\",\"LI\",\"LK\",\"LR\",\"LS\",\"LT\",\"LU\",\"LV\",\"LY\",\"MA\",\"MC\",\"MD\",\"ME\",\"MG\",\"MH\",\"MK\",\"ML\",\"MM\",\"MN\",\"MO\",\"MP\",\"MQ\",\"MR\",\"MS\",\"MT\",\"MT\",\"MU\",\"MV\",\"MW\",\"MX\",\"MY\",\"MZ\",\"NA\",\"NC\",\"NE\",\"NF\",\"NG\",\"NI\",\"NL\",\"NO\",\"NP\",\"NR\",\"NU\",\"NZ\",\"OM\",\"PA\",\"PE\",\"PF\",\"PG\",\"PH\",\"PK\",\"PL\",\"PM\",\"PN\",\"PR\",\"PS\",\"PT\",\"PW\",\"PY\",\"QA\",\"RE\",\"RO\",\"RS\",\"RU\",\"RW\",\"SA\",\"SB\",\"SC\",\"SD\",\"SE\",\"SG\",\"SH\",\"SI\",\"SJ\",\"SK\",\"SL\",\"SM\",\"SN\",\"SO\",\"SR\",\"SS\",\"ST\",\"SV\",\"SX\",\"SY\",\"SZ\",\"TC\",\"TD\",\"TF\",\"TG\",\"TH\",\"TJ\",\"TK\",\"TL\",\"TM\",\"TN\",\"TO\",\"TR\",\"TT\",\"TV\",\"TW\",\"TZ\",\"UA\",\"UG\",\"UM\",\"US\",\"UY\",\"UZ\",\"VA\",\"VA\",\"VC\",\"VE\",\"VG\",\"VI\",\"VN\",\"VU\",\"WF\",\"WS\",\"YE\",\"YT\",\"YU\",\"ZA\",\"ZM\",\"ZW\"]');
/*!40000 ALTER TABLE `options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ou_types`
--

DROP TABLE IF EXISTS `ou_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ou_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `attributes` longtext NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ou_types`
--

LOCK TABLES `ou_types` WRITE;
/*!40000 ALTER TABLE `ou_types` DISABLE KEYS */;
INSERT INTO `ou_types` VALUES (1,'unit','Standard Organizational Unit','A standard organizational unit definition','{\"auto_form_fields\":[],\"fields\":{\"objectclass\":[\"top\",\"organizationalunit\"]},\"form_fields\":{\"ou\":[],\"description\":[],\"aci\":{\"optional\":true,\"type\":\"aci\"}}}',0);
/*!40000 ALTER TABLE `ou_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resource_types`
--

DROP TABLE IF EXISTS `resource_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resource_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `attributes` longtext NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resource_types`
--

LOCK TABLES `resource_types` WRITE;
/*!40000 ALTER TABLE `resource_types` DISABLE KEYS */;
INSERT INTO `resource_types` VALUES (1,'collection','Resource Collection','A collection or pool of resources','{\"auto_form_fields\":{\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"groupofuniquenames\",\"kolabgroupofuniquenames\"]},\"form_fields\":{\"cn\":[],\"ou\":{\"type\":\"select\"},\"uniquemember\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(2,'car','Car','A car','{\"auto_form_fields\":{\"cn\":{\"data\":[\"cn\"]},\"kolabtargetfolder\":{\"data\":[\"cn\"]},\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"kolabsharedfolder\",\"mailrecipient\"],\"kolabfoldertype\":[\"event\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true},\"cn\":[],\"ou\":{\"type\":\"select\"},\"owner\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(3,'confroom','Conference Room','A conference room','{\"auto_form_fields\":{\"cn\":{\"data\":[\"cn\"]},\"kolabtargetfolder\":{\"data\":[\"cn\"]},\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"kolabsharedfolder\",\"mailrecipient\"],\"kolabfoldertype\":[\"event\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true},\"cn\":[],\"ou\":{\"type\":\"select\"},\"owner\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(4,'projector','Projector','A portable overhead projector','{\"auto_form_fields\":{\"cn\":{\"data\":[\"cn\"]},\"kolabtargetfolder\":{\"data\":[\"cn\"]},\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"kolabsharedfolder\",\"mailrecipient\"],\"kolabfoldertype\":[\"event\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true},\"cn\":[],\"ou\":{\"type\":\"select\"},\"owner\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0),(5,'footballtickets','Football Season Tickets','Season tickets to the game (pretty good seats too!)','{\"auto_form_fields\":{\"cn\":{\"data\":[\"cn\"]},\"kolabtargetfolder\":{\"data\":[\"cn\"]},\"mail\":{\"data\":[\"cn\"]}},\"fields\":{\"objectclass\":[\"top\",\"kolabsharedfolder\",\"mailrecipient\"],\"kolabfoldertype\":[\"event\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true},\"cn\":[],\"ou\":{\"type\":\"select\"},\"owner\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true}}}',0);
/*!40000 ALTER TABLE `resource_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_types`
--

DROP TABLE IF EXISTS `role_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `attributes` longtext NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_types`
--

LOCK TABLES `role_types` WRITE;
/*!40000 ALTER TABLE `role_types` DISABLE KEYS */;
INSERT INTO `role_types` VALUES (1,'simple_managed','Standard Role','A standard role definition','{\"auto_form_fields\":[],\"fields\":{\"objectclass\":[\"top\",\"ldapsubentry\",\"nsroledefinition\",\"nssimpleroledefinition\",\"nsmanagedroledefinition\"]},\"form_fields\":{\"cn\":[],\"description\":[]}}',0);
/*!40000 ALTER TABLE `role_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sharedfolder_types`
--

DROP TABLE IF EXISTS `sharedfolder_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sharedfolder_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `attributes` longtext NOT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sharedfolder_types`
--

LOCK TABLES `sharedfolder_types` WRITE;
/*!40000 ALTER TABLE `sharedfolder_types` DISABLE KEYS */;
INSERT INTO `sharedfolder_types` VALUES (1,'addressbook','Shared Address Book','A shared address book','{\"auto_form_fields\":[],\"fields\":{\"kolabfoldertype\":[\"contact\"],\"objectclass\":[\"top\",\"kolabsharedfolder\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"cn\":[]}}',0),(2,'calendar','Shared Calendar','A shared calendar','{\"auto_form_fields\":[],\"fields\":{\"kolabfoldertype\":[\"event\"],\"objectclass\":[\"top\",\"kolabsharedfolder\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"cn\":[]}}',0),(3,'journal','Shared Journal','A shared journal','{\"auto_form_fields\":[],\"fields\":{\"kolabfoldertype\":[\"journal\"],\"objectclass\":[\"top\",\"kolabsharedfolder\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"cn\":[]}}',0),(4,'task','Shared Tasks','A shared tasks folder','{\"auto_form_fields\":[],\"fields\":{\"kolabfoldertype\":[\"task\"],\"objectclass\":[\"top\",\"kolabsharedfolder\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"cn\":[]}}',0),(5,'note','Shared Notes','A shared Notes folder','{\"auto_form_fields\":[],\"fields\":{\"kolabfoldertype\":[\"note\"],\"objectclass\":[\"top\",\"kolabsharedfolder\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"cn\":[]}}',0),(6,'file','Shared Files','A shared Files folder','{\"auto_form_fields\":[],\"fields\":{\"kolabfoldertype\":[\"file\"],\"objectclass\":[\"top\",\"kolabsharedfolder\"]},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"cn\":[]}}',0),(7,'mail','Shared Mail Folder','A shared mail folder','{\"fields\":{\"objectclass\":[\"kolabsharedfolder\",\"mailrecipient\",\"top\"],\"kolabfoldertype\":\"mail\"},\"form_fields\":{\"acl\":{\"type\":\"imap_acl\",\"optional\":true,\"default\":\"anyone, lrs\"},\"alias\":{\"type\":\"list\",\"optional\":true},\"cn\":[],\"kolaballowsmtprecipient\":{\"type\":\"list\",\"optional\":true},\"kolaballowsmtpsender\":{\"type\":\"list\",\"optional\":true},\"kolabdelegate\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true},\"mail\":[]},\"auto_form_fields\":{\"kolabtargetfolder\":{\"data\":[\"cn\"]}}}',0);
/*!40000 ALTER TABLE `sharedfolder_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `attributes` longtext NOT NULL,
  `used_for` varchar(16) DEFAULT NULL,
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_types`
--

LOCK TABLES `user_types` WRITE;
/*!40000 ALTER TABLE `user_types` DISABLE KEYS */;
INSERT INTO `user_types` VALUES (1,'kolab','Kolab User','A Kolab User','{\"auto_form_fields\":{\"alias\":{\"type\":\"list\",\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"cn\":{\"data\":[\"givenname\",\"sn\"]},\"displayname\":{\"data\":[\"givenname\",\"sn\"]},\"mail\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"mailhost\":{\"optional\":true},\"uid\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"userpassword\":{\"optional\":true}},\"form_fields\":{\"alias\":{\"type\":\"list\",\"optional\":true},\"givenname\":[],\"initials\":{\"optional\":true},\"kolabdelegate\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true},\"kolabinvitationpolicy\":{\"type\":\"select\",\"values\":[\"\",\"ACT_MANUAL\",\"ACT_REJECT\"],\"optional\":true},\"kolaballowsmtprecipient\":{\"type\":\"list\",\"optional\":true},\"kolaballowsmtpsender\":{\"type\":\"list\",\"optional\":true},\"l\":{\"optional\":true},\"mailalternateaddress\":{\"type\":\"list\",\"optional\":true},\"mailquota\":{\"type\":\"text-quota\",\"optional\":true},\"mobile\":{\"optional\":true},\"nsroledn\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true},\"o\":{\"optional\":true},\"ou\":{\"type\":\"select\"},\"pager\":{\"optional\":true},\"postalcode\":{\"optional\":true},\"preferredlanguage\":{\"type\":\"select\"},\"sn\":[],\"street\":{\"optional\":true},\"telephonenumber\":{\"optional\":true},\"title\":{\"optional\":true},\"userpassword\":{\"optional\":true}},\"fields\":{\"objectclass\":[\"top\",\"inetorgperson\",\"kolabinetorgperson\",\"mailrecipient\",\"organizationalperson\",\"person\"]}}',NULL,1),(2,'posix','POSIX User','A POSIX user (with a home directory and shell access)','{\"auto_form_fields\":{\"cn\":{\"data\":[\"givenname\",\"sn\"]},\"displayname\":{\"data\":[\"givenname\",\"sn\"]},\"gidnumber\":[],\"homedirectory\":{\"data\":[\"givenname\",\"sn\"]},\"uid\":{\"data\":[\"givenname\",\"sn\"]},\"uidnumber\":[],\"userpassword\":{\"optional\":true}},\"form_fields\":{\"givenname\":[],\"initials\":{\"optional\":true},\"preferredlanguage\":{\"type\":\"select\",\"values\":[\"en_US\",\"de_DE\",\"de_CH\",\"en_GB\",\"fi_FI\",\"fr_FR\",\"hu_HU\"]},\"loginshell\":{\"type\":\"select\",\"values\":[\"/bin/bash\",\"/usr/bin/git-shell\",\"/sbin/nologin\"]},\"ou\":{\"type\":\"select\"},\"sn\":[],\"title\":{\"optional\":true},\"userpassword\":{\"optional\":true}},\"fields\":{\"objectclass\":[\"top\",\"inetorgperson\",\"organizationalperson\",\"person\",\"posixaccount\"]}}',NULL,0),(3,'kolab_posix','Mail-enabled POSIX User','A mail-enabled POSIX User','{\"auto_form_fields\":{\"alias\":{\"type\":\"list\",\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"cn\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"displayname\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"gidnumber\":[],\"homedirectory\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"mail\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"mailhost\":{\"optional\":true},\"uid\":{\"data\":[\"givenname\",\"preferredlanguage\",\"sn\"]},\"uidnumber\":[],\"userpassword\":{\"optional\":true}},\"form_fields\":{\"alias\":{\"type\":\"list\",\"optional\":true},\"givenname\":[],\"initials\":{\"optional\":true},\"kolabdelegate\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true},\"kolabinvitationpolicy\":{\"type\":\"select\",\"values\":[\"\",\"ACT_MANUAL\",\"ACT_REJECT\"],\"optional\":true},\"kolaballowsmtprecipient\":{\"type\":\"list\",\"optional\":true},\"kolaballowsmtpsender\":{\"type\":\"list\",\"optional\":true},\"l\":{\"optional\":true},\"loginshell\":{\"type\":\"select\",\"values\":[\"/bin/bash\",\"/usr/bin/git-shell\",\"/sbin/nologin\"]},\"mailalternateaddress\":{\"type\":\"list\",\"optional\":true},\"mailquota\":{\"type\":\"text-quota\",\"optional\":true},\"mobile\":{\"optional\":true},\"nsroledn\":{\"type\":\"list\",\"autocomplete\":true,\"optional\":true},\"o\":{\"optional\":true},\"ou\":{\"type\":\"select\"},\"pager\":{\"optional\":true},\"postalcode\":{\"optional\":true},\"preferredlanguage\":{\"type\":\"select\"},\"sn\":[],\"street\":{\"optional\":true},\"telephonenumber\":{\"optional\":true},\"title\":{\"optional\":true},\"userpassword\":{\"optional\":true}},\"fields\":{\"objectclass\":[\"top\",\"inetorgperson\",\"kolabinetorgperson\",\"mailrecipient\",\"organizationalperson\",\"person\",\"posixaccount\"]}}',NULL,0),(4,'contact','Contact','A global address book contact','{\"auto_form_fields\":{\"cn\":{\"data\":[\"givenname\",\"sn\"]},\"displayname\":{\"data\":[\"givenname\",\"sn\"]},\"uid\":{\"data\":[\"givenname\",\"sn\"]},\"userpassword\":{\"optional\":true}},\"form_fields\":{\"cn\":{\"optional\":true},\"displayname\":{\"optional\":true},\"givenname\":[],\"initials\":{\"optional\":true},\"l\":{\"optional\":true},\"mail\":{\"type\":\"list\",\"optional\":true},\"mailalternateaddress\":{\"type\":\"list\",\"optional\":true},\"mobile\":{\"optional\":true},\"o\":{\"optional\":true},\"ou\":{\"type\":\"select\"},\"pager\":{\"optional\":true},\"postalcode\":{\"optional\":true},\"sn\":[],\"street\":{\"optional\":true},\"telephonenumber\":{\"optional\":true},\"title\":{\"optional\":true},\"userpassword\":{\"optional\":true}},\"fields\":{\"objectclass\":[\"top\",\"inetorgperson\",\"mailrecipient\",\"organizationalperson\",\"person\"]}}',NULL,0),(5,'forwarding','Mail Forwarding','A mail forwarding account (forwarding only!)','{\"auto_form_fields\":{\"cn\":{\"data\":[\"givenname\",\"sn\"]},\"displayname\":{\"data\":[\"givenname\",\"sn\"]},\"uid\":{\"data\":[\"givenname\",\"sn\"]},\"userpassword\":{\"optional\":true}},\"form_fields\":{\"cn\":{\"optional\":true},\"displayname\":{\"optional\":true},\"givenname\":[],\"initials\":{\"optional\":true},\"l\":{\"optional\":true},\"mail\":{\"type\":\"list\",\"optional\":true},\"mailalternateaddress\":{\"type\":\"list\",\"optional\":true},\"mailforwardingaddress\":{\"type\":\"list\"},\"mobile\":{\"optional\":true},\"o\":{\"optional\":true},\"ou\":{\"type\":\"select\"},\"pager\":{\"optional\":true},\"postalcode\":{\"optional\":true},\"sn\":[],\"street\":{\"optional\":true},\"telephonenumber\":{\"optional\":true},\"title\":{\"optional\":true},\"userpassword\":{\"optional\":true}},\"fields\":{\"objectclass\":[\"top\",\"inetorgperson\",\"mailrecipient\",\"organizationalperson\",\"person\"]}}',NULL,0);
/*!40000 ALTER TABLE `user_types` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-08-20 11:43:03
