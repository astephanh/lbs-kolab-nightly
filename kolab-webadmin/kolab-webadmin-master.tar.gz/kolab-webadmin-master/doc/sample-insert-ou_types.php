#!/usr/bin/php
<?php

    if (isset($_SERVER["REQUEST_METHOD"]) && !empty($SERVER["REQUEST_METHOD"])) {
        die("Not intended for execution through the webserver, sorry!");
    }

    require_once("lib/functions.php");

    $db   = SQL::get_instance();

    $result = $db->query("TRUNCATE TABLE `ou_types`");

    $attributes = Array(
            "auto_form_fields" => Array(
                ),
            "fields" => Array(
                    "objectclass" => Array(
                            "top",
                            "organizationalunit",
                        ),
                ),
            "form_fields" => Array(
                    "ou" => Array(),
                    "description" => Array(
                        "optional" => true,
                    ),
                ),
        );

    $result = $db->query("INSERT INTO `ou_types` (`key`, `name`, `description`, `attributes`) " .
                "VALUES ('simple_managed','Standard Organizational Unit', 'A standard organizational unit definition'," .
                "'" . json_encode($attributes) . "')");

?>
