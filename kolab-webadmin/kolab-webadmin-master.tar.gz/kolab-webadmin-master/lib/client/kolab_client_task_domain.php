<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2012, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 +--------------------------------------------------------------------------+
*/

class kolab_client_task_domain extends kolab_client_task
{
    protected $ajax_only = true;

    protected $menu = array(
        'add'  => 'domain.add',
    );

    protected $search_attribs = array(
        'name' => array('associateddomain'),
    );

    protected $list_attribs = array('associateddomain', 'inetdomainstatus');

    /**
     * Default action.
     */
    public function action_default()
    {
        $this->output->set_object('content', 'domain', true);
        $this->output->set_object('task_navigation', $this->menu());

        $this->action_list();

        // display form to add domain if logged-in user has right to do so
        $caps = $this->get_capability('actions');
        if (!empty($caps['domain.add'])) {
            $this->action_add();
        }
        else {
            $this->output->command('set_watermark', 'taskcontent');
        }
    }

    /**
     * Groups list action.
     */
    public function action_list()
    {
        if (!empty($_POST['refresh'])) {
            // refresh domains list
            if ($domains = $this->get_domains(true)) {
                sort($domains, SORT_LOCALE_STRING);
                $this->output->set_env('domains', $domains);
            }
        }

        parent::action_list();
    }

    /**
     * Domain information (form) action.
     */
    public function action_info()
    {
        $id = $this->get_input('id', 'POST');

        $result = $this->api_get('domain.info', array('id' => $id));
        $domain = $result->get();
        $output = $this->domain_form(array_keys($domain), $domain);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * Domain adding (form) action.
     */
    public function action_add()
    {
        $data   = $this->get_input('data', 'POST');
        $output = $this->domain_form(null, $data, true);

        $this->output->set_object('taskcontent', $output);
    }

    /**
     * Domain edit/add form.
     */
    private function domain_form($attribs, $data = array())
    {
        if (empty($attribs['id'])) {
            $attribs['id'] = 'domain-form';
        }

        // Form sections
        $sections = array(
            'system'   => 'domain.system',
            'other'    => 'domain.other',
        );

        // field-to-section map and fields order
        $fields_map = array(
            'type_id'           => 'system',
            'type_id_name'      => 'system',
            'associateddomain'  => 'system',
            'inetdomainstatus'  => 'system',
        );

        // Prepare fields
        $form = $this->form_prepare('domain', $data, array(), null, $fields_map['type_id']);
        list($fields, $types, $type, $add_mode) = $form;

        // Create mode
        if ($add_mode) {
            // Page title
            $title = $this->translate('domain.add');
        }
        // Edit mode
        else {
            if (array_key_exists('primary_domain', $data)) {
                $title = $data['primary_domain'];
            }
            // TODO: Domain name attribute.
            else if (!is_array($data['associateddomain'])) {
                $title = $data['associateddomain'];
            }
            else {
                $title = $data['associateddomain'][0];
            }
        }

        // Create form object and populate with fields
        $form = $this->form_create('domain', $attribs, $sections, $fields, $fields_map, $data, $add_mode, $title);

        return $form->output();
    }

    /**
     * List item handler
     */
    protected function list_item_handler($item, &$class)
    {
        if ($item['inetdomainstatus'] == 'deleted') {
            $class[] = 'deleted';
        }

        if (is_array($item['associateddomain'])) {
            return $item['associateddomain'][0];
        }

        return $item['associateddomain'];
    }

    /**
     * Returns false when object matches current domain
     */
    protected function is_deletable($data)
    {
        // domain delete is done by setting inetdomainstatus to 'deleted'
        return false;
    }

}
