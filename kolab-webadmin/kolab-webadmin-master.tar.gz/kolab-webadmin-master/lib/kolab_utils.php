<?php
/*
 +--------------------------------------------------------------------------+
 | This file is part of the Kolab Web Admin Panel                           |
 |                                                                          |
 | Copyright (C) 2011-2012, Kolab Systems AG                                |
 |                                                                          |
 | This program is free software: you can redistribute it and/or modify     |
 | it under the terms of the GNU Affero General Public License as published |
 | by the Free Software Foundation, either version 3 of the License, or     |
 | (at your option) any later version.                                      |
 |                                                                          |
 | This program is distributed in the hope that it will be useful,          |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of           |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the             |
 | GNU Affero General Public License for more details.                      |
 |                                                                          |
 | You should have received a copy of the GNU Affero General Public License |
 | along with this program. If not, see <http://www.gnu.org/licenses/>      |
 +--------------------------------------------------------------------------+
 | Author: Aleksander Machniak <machniak@kolabsys.com>                      |
 | Author: Jeroen van Meeuwen <vanmeeuwen@kolabsys.com>                     |
 +--------------------------------------------------------------------------+
*/

/**
 * Utilities class
 */
class kolab_utils
{
    const REQUEST_ANY  = 0;
    const REQUEST_GET  = 1;
    const REQUEST_POST = 2;

    /**
     * Read a specific HTTP request header
     *
     * @param string $name  Header name
     *
     * @return mixed  Header value or null if not available
     */
    public static function get_request_header($name)
    {
        if (function_exists('getallheaders')) {
            $hdrs = array_change_key_case(getallheaders(), CASE_UPPER);
            $key  = strtoupper($name);
        }
        else {
            $key  = 'HTTP_' . strtoupper(strtr($name, '-', '_'));
            $hdrs = array_change_key_case($_SERVER, CASE_UPPER);
        }

        return $hdrs[$key];
    }

    /**
     * Returns input parameter value.
     *
     * @param string $name       Parameter name
     * @param int    $type       Parameter type
     * @param bool   $allow_html Disables stripping of insecure content (HTML tags)
     *
     * @return mixed Input value
     */
    public static function get_input($name, $type = null, $allow_html = false)
    {
        if ($type == self::REQUEST_GET) {
            $value = isset($_GET[$name]) ? $_GET[$name] : null;
        }
        else if ($type == self::REQUEST_POST) {
            $value = isset($_POST[$name]) ? $_POST[$name] : null;
        }
        else {
            $value = isset($_REQUEST[$name]) ? $_REQUEST[$name] : null;
        }

        return self::parse_input($value, $allow_html);
    }

    /**
     * Input parsing.
     *
     * @param mixed  $value      Input value
     * @param bool   $allow_html Disables stripping of insecure content (HTML tags)
     *
     * @return mixed Input value
     */
    public static function parse_input($value, $allow_html = false)
    {
        if (empty($value)) {
            return $value;
        }

        if (is_array($value)) {
            foreach ($value as $idx => $val) {
                $value[$idx] = self::parse_input($val, $allow_html);
            }
        }
        // remove HTML tags if not allowed
        else if (!$allow_html) {
            $value = strip_tags($value);
        }

        return $value;
    }

    /**
     * Make sure the string ends with a slash
     *
     * @param string $str String to parse
     *
     * @return string String with one slash at the end
     */
    public static function slashify($str)
    {
        return self::unslashify($str).'/';
    }

    /**
     * Remove slash at the end of the string
     *
     * @param string $str String to parse
     *
     * @return string String without any slashes at the end
     */
    public static function unslashify($str)
    {
        return preg_replace('/\/$/', '', $str);
    }

    /**
     * Check if secure protocol is being used.
     *
     * @return bool True when using https protocol, False otherwise
     */
    public static function https_check()
    {
        if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) != 'off') {
            return true;
        }

        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower($_SERVER['HTTP_X_FORWARDED_PROTO']) == 'https') {
            return true;
        }

        return false;
    }

    /**
     * Finds wether an array is associative or not.
     */
    public static function is_assoc($arr)
    {
        return is_array($arr) && count(array_filter(array_keys($arr), 'is_string')) == count($arr);
    }

    /**
     * Unicode-aware ldap_dn2ufn() wrapper
     *
     * @param string $dn LDAP DN string
     *
     * @return string Human-readable string
     */
    public static function dn2ufn($dn)
    {
        return self::decode_dn(ldap_dn2ufn($dn));
    }

    /**
     * Unicode-aware ldap_explode_dn() wrapper
     *
     * @param string $dn LDAP DN string
     *
     * @return array|bool Exploded DN (uses unicode encoding), False on failure
     */
    public static function explode_dn($dn)
    {
        if ($result = ldap_explode_dn($dn, 0)) {
            // get rid of count
            unset($result['count']);

            $result = array_map(array('kolab_utils', 'decode_dn'), $result);
        }

        return $result;
    }

    /**
     * Decode \XX sequences into characters
     *
     * @param string $str String to decode
     *
     * @return string Decoded string
     */
    public static function decode_dn($str)
    {
        $pos  = 0;

        // example: "\C3\A4" => "ä"
        while (preg_match('/\\\\[0-9a-fA-F]{2}/', $str, $matches, PREG_OFFSET_CAPTURE, $pos)) {
            $char = chr(hexdec(substr($matches[0][0], 1)));
            $pos  = $matches[0][1];
            $str  = substr_replace($str, $char, $pos, 3);
            $pos += 1;
        }

        return $str;
    }

    /**
     * Escape string for use in javascript code
     *
     * @param string $str String
     *
     * @return string Escaped string
     */
    public static function js_escape($str)
    {
        return strtr($str, array(
                '"'  => '\\"',
                "'"  => "\\'",
                "\\" => "\\\\",
                "\n" => '\n',
        ));
    }
}
