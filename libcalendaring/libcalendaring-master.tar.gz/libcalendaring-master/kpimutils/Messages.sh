#! /bin/sh
$XGETTEXT *.cpp *.h -o $podir/libkpimutils.pot
