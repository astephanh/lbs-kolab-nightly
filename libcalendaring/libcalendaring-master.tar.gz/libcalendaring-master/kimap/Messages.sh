#! /bin/sh
$XGETTEXT *.cpp -o $podir/libkimap.pot
