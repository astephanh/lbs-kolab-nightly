#! /bin/sh
$XGETTEXT *.cpp *.h -o $podir/libkmime.pot
