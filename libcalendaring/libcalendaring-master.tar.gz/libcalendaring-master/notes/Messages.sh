#! /bin/sh
$XGETTEXT *.cpp -o $podir/akonadinotes.pot
