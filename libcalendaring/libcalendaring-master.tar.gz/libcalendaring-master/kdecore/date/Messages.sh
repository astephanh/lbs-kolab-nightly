#!/bin/bash
$XGETTEXT $(find -name "kcalendarsystem*.cpp") -o $podir/kdecalendarsystems.pot
