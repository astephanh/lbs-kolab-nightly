Some test files that were shipped with libical-> They don't have have a 
specific purpose, but server as general tests.


Several of the original test cases are moved to other directories of this test suite:
LibICal_TestCase14.ics: UntilInUTC/Until_TestCase06.ics
LibICal_TestCase13.ics: UntilInUTC/Until_TestCase05.ics
LibICal_TestCase47.ics: UntilInUTC/Until_TestCase04.ics
LibICal_TestCase22.ics: UntilInUTC/Until_TestCase03.ics
