Some test event from ConnectDaily.
