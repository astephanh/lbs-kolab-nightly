import sys

sys.path = [ '.', '..' ] + sys.path

