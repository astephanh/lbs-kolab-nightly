import sys

def setup_module():
    sys.path = ['.'] + sys.path
