.. index:: Calendar
.. _calendar:

********
Calendar
********

The *Calendar* gives you access to your personal and shared calendar and scheduling functions.

.. toctree::
   :maxdepth: 2

   overview
   manage
   invitations
   importexport
   sharing

