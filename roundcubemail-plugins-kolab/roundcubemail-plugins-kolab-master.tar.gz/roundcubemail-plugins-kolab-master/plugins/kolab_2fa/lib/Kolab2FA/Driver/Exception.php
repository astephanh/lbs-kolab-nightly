<?php

namespace Kolab2FA\Driver;

class Exception extends \Exception
{
    
}
