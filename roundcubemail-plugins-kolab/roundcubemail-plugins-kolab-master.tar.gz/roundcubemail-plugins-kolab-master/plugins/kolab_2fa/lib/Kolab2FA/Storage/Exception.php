<?php

namespace Kolab2FA\Storage;

class Exception extends \Exception
{
    
}
