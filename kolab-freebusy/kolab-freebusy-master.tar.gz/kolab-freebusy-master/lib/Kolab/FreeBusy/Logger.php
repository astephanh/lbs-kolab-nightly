<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

use Kolab\Config;
use Monolog\Logger as Monologger;
use Monolog\Handler\StreamHandler;
use Monolog\Handler\SyslogHandler;
use Monolog\Handler\NullHandler;

/**
 * Helper class for creating up Monolog instanced with local configration
 */
class Logger
{
	private static $instances = array();

	/**
	 * Static getter for a Monolog\Logger instance
	 */
	public static function get($name, $level = 0)
	{
		if (!isset(self::$instances[$name]) || ($level && !self::$instances[$name]->isHandling($level))) {
			$logger = new Monologger($name);

			// read log config
			$config = Config::get_instance();
			$identity = $config->get('log.name', 'freebusy');
			$loglevel = $level ?: $config->get('log.level', Monologger::INFO);

			switch ($config->get('log.driver')) {
				case 'file':
					$logdir = Utils::abspath($config->get('log.path'), '/');
					$logger->pushHandler(new StreamHandler($logdir . $identity . '.log', $loglevel));
					break;

				case 'syslog':
					$logger->pushHahdler(new SyslogHandler($identity, $config->get('log.facility', 'user'), $loglevel));
					break;

				default:
					// null handler if logging is disabled
					$logger->pushHandler(new NullHandler);
			}

			self::$instances[$name] = $logger;
		}
		
		return self::$instances[$name];
	}

}

