<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

use Kolab\Config;

/**
 * Abstract class representing an address directory for free/busy data lookups
 */
abstract class Directory
{
	protected $config;

	/**
	 * Factory method creating an instace of Directory according to config
	 *
	 * @param array Hash array with config
	 */
	public static function factory($config)
	{
		switch (strtolower($config['type'])) {
			case 'ldap':
				return new DirectoryLDAP($config);

			case 'static':
			case 'external':
				return new DirectoryStatic($config);

			default:
				Logger::get('directory')->addError("Invalid directory type '" . $config['type'] . "'!");
		}

		return null;
	}

	/**
	 * Resolve the given username to a Entity object
	 *
	 * @param string Username/Email to resolve
	 * @return object Entity if found, otherwise False
	 */
	abstract public function resolve($user);

	/**
	 * Retrieve free/busy data for the given user.
	 *
	 * @param string Username or email to resolve
	 * @param boolean Get extemded free-busy if possible
	 * @return string VCalendar container if found, False otherwise
	 */
	public function getFreeBusyData($user, $extended = false)
	{
		// resolve user record first
		if ($user = $this->resolve($user)) {
			$fbsource = $this->config['fbsource'];
			if ($source = Source::Factory($fbsource, $this->config)) {
				// forward request to Source instance
				if ($data = $source->getFreeBusyData($this->postprocessAttrib($user), $extended)) {
					// send data through the according format converter
					$converter = Format::factory($this->config['format']);
					$data = $converter->toVCalendar($data);

					// cache the generated data
					if ($data && $this->config['cacheto'] && !$source->isCached()) {
						$path = preg_replace_callback(
							'/%\{?([a-z0-9]+)\}?/',
							function($m) use ($user) { return $user[$m[1]]; },
							$this->config['cacheto']
						);

						if (!@file_put_contents($path, $data, LOCK_EX)) {
							Logger::get('directory')->addError("Failed to write to cache file '" . $path . "'!");
						}
					}
				}

				return $data;
			}
		}

		return false;
	}

	/**
	 * Modify attribute values according to config
	 */
	protected function postprocessAttrib($attrib)
	{
		if (!empty($this->config['lc_attributes'])) {
			foreach (Config::convert($this->config['lc_attributes'], Config::ARR) as $key) {
				if (!empty($attrib[$key]))
					$attrib[$key] = strtolower($attrib[$key]);
			}
		}

		return $attrib;
	}

}