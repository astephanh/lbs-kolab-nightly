<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

/**
 * Implementation of a Free/Busy data source reading from the local file system
 */
class SourceFile extends Source
{
	/**
	 * @see Source::getFreeBusyData()
	 */
	public function getFreeBusyData($user, $extended)
	{
		// get source config with placeholders replaced
		$config = $this->getUserConfig($user);

		// deliver file contents if found
		if (is_readable($config['path'])) {
			// check expiration if configured
			if (empty($this->config['expires']) || filemtime($config['path']) + Utils::getOffsetSec($this->config['expires']) > time()) {
				return file_get_contents($config['path']);
			}
		}

		// not found
		return false;
	}
}
