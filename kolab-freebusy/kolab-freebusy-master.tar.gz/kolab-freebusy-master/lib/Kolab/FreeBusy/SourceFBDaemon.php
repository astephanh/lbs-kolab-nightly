<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2014, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

/**
 * Implementation of a Free/Busy data source reading from kolab-freebusyd service
 */
class SourceFBDaemon extends Source
{
	/**
	 * @see Source::getFreeBusyData()
	 */
	public function getFreeBusyData($user, $extended)
	{
		$log = Logger::get('fbdaemon', intval($this->config['loglevel']));

		$config = $this->getUserConfig($user);
		parse_str(strval($config['query']), $param);
		$config += $param;

		// log this...
		$log->addInfo("Fetching data for ", $config);

		// caching is enabled
		if (!empty($config['cacheto'])) {
			// check for cached data
			if ($cached = $this->getCached($config)) {
				$log->addInfo("Deliver cached data from " . $config['cacheto']);
				return $cached;
			}
			// touch cache file to avoid multiple requests generating the same data
			if (file_exists($config['cacheto'])) {
				touch($config['cacheto']);
			}
			else {
				file_put_contents($config['cacheto'], Utils::dummyVFreebusy($user['mail']));
				$tempfile = $config['cacheto'];
			}
		}

		// compose command for freebusyd
		if (!empty($config['folder'])) {
			$cmd = 'FOLDER';
			$target = $config['folder'];
		}
		else if (!empty($config['user'])) {
			$cmd = 'USER';
			$target = $config['user'];
		}
		else {
			$log->addWarning("No valid target user/name specified", $config);
		}

		// open connection to fbdaemon and execute IFB command
		if (!empty($cmd) && ($fp = fsockopen($config['host'], $config['port'], $errno, $errstr, 5))) {
			$timeout = $config['timeout'] ? intval($config['timeout']) : max(10, ini_get('max_execution_time')) - 5;
			stream_set_timeout($fp , $timeout);

			$start = Utils::periodStart();
			$end   = Utils::periodEnd();

			$send = sprintf('IFB %s "%s" slot:%d-%d'."\n", $cmd, $target, $start, $end);
			$log->debug('C: ' . $send, array('start' => gmdate('Y-m-d\TH:i:s\Z', $start), 'end' => gmdate('Y-m-d\TH:i:s\Z', $end), 'timeout' => $timeout));
			$fbdata = false;

			fwrite($fp, $send);
			while (!feof($fp)) {
				$line = fgets($fp, 128);
				$log->debug('S: ' . $line);
				$len = 0;

				// detect response header
				if (preg_match('/^\*\s+\(\{(\d+)\}/', $line, $m)) {
					$len = intval($m[1]);
					if ($len > 0) {
						$fbdata = fread($fp, $len);
						$log->debug("S: " . $fbdata);
					}
				}

				// exit loop if result complete
				if (preg_match('/^(OK|BAD)\s+/', $line, $m)) {
					if ($m[1] == 'BAD') {
						$log->addWarning("BAD response from kolab-freebusyd", array('request' => $send, 'response' => $line));
					}
					break;
				}
			}

			fclose($fp);
		}

		// log daemon connection errors
		if ($errno || $errstr) {
			$log->addError("Cannot connect to kolab-freebusyd", array(
				'errno' => $errno,
				'error' => $errstr,
				'host' => $config['host'],
				'port' => $config['port'],
			));
		}

		if (!empty($fbdata)) {
			// post-process fbdata (replace ORGANIZER: property)
			if (!empty($user['mail'])) {
				$fbdata = preg_replace('/(ORGANIZER:mailto:)(.+)/i', '\1' . $user['mail'], $fbdata);
			}
			return $fbdata;
		}
		// remove (temporary) cache file again
		else if ($tempfile) {
			unlink($tempfile);
		}

		// not found
		return false;
	}
}
