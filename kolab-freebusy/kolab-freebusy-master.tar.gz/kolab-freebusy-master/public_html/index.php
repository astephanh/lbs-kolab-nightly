<?php

/**
 * Kolab Server Free/Busy Service Endpoint
 *
 * This is the public API to provide Free/Busy information for Kolab users.
 *
 * @version 0.1.4
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2014, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */


define('KOLAB_FREEBUSY_ROOT', realpath('../'));

// suppress error notices
ini_set('error_reporting', E_ALL &~ E_NOTICE);

// use composer's autoloader for both dependencies and local lib
$loader = require_once(KOLAB_FREEBUSY_ROOT . '/vendor/autoload.php');
$loader->set('Kolab', array(KOLAB_FREEBUSY_ROOT . '/lib'));  // register Kolab namespace
$loader->setUseIncludePath(true);  // enable searching the include_path (e.g. for PEAR packages)

use Kolab\Config;
use Kolab\FreeBusy\Utils;
use Kolab\FreeBusy\Logger;
use Kolab\FreeBusy\Directory;
use Kolab\FreeBusy\HTTPAuth;


// load config
$config = Config::get_instance(KOLAB_FREEBUSY_ROOT . '/config');
if ($config->valid()) {
	// check for trusted IP first
	$remote_ip = Utils::remoteIP();
	$trusted_ip = $config->trustednetworks ? Utils::checkIPRange($remote_ip, $config->get('trustednetworks.allow', array(), Config::ARR)) : false;

	$log = Logger::get('web');

	$uri = $_SERVER['REDIRECT_URL'];

	// we're not always redirected here
	if (empty($uri)) {
		$uri = $_SERVER['REQUEST_URI'];
		$log->addDebug('Request (direct): ' . $uri, array('ip' => $remote_ip, 'trusted' => $trusted_ip));
	} else {
		$log->addDebug('Request (redirect): ' . $uri, array('ip' => $remote_ip, 'trusted' => $trusted_ip));
	}

	// check HTTP authentication
	if (!$trusted_ip && $config->httpauth) {
		if (!HTTPAuth::check($config->httpauth)) {
			$log->addDebug("Abort with 401 Unauthorized");
			header('WWW-Authenticate: Basic realm="Kolab Free/Busy Service"');
			header($_SERVER['SERVER_PROTOCOL'] . " 401 Unauthorized", true);
			exit;
		}
	}

	#header('Content-type: text/calendar; charset=utf-8', true);
	header('Content-type: text/plain; charset=utf-8', true);

	// analyse request
	$url = array_filter(explode('/', $uri));
	$user = strtolower(array_pop($url));
	$action = strtolower(array_pop($url));
	$extended = false;

	// remove file extension
	if (preg_match('/^(.+)\.([ipx]fb)$/i', $user, $m)) {
		$user = urldecode($m[1]);
		$extended = $m[2] == 'xfb';
	}

	// iterate over directories
	foreach ($config->directory as $key => $dirconfig) {
		$log->addDebug("Trying directory $key", $dirconfig);

		$directory = Directory::factory($dirconfig);
		if ($directory && ($fbdata = $directory->getFreeBusyData($user, $extended))) {
			$log->addInfo("Found valid data for user $user in directory $key");
			echo $fbdata;
			exit;
		}
	}

	// return 404 if request was sent from a trusted IP
	if ($trusted_ip) {
		$log->addDebug("Returning '404 Not Found' for user $user");
		header($_SERVER['SERVER_PROTOCOL'] . " 404 Not found", true);
	}
	else {
		$log->addInfo("Returning empty Free/Busy list for user $user");

		// Return an apparent empty Free/Busy list.
		print Utils::dummyVFreebusy($user);
	}
}

// exit with error
# header($_SERVER['SERVER_PROTOCOL'] . " 500 Internal Server Error", true);

