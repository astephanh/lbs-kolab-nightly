<?php

/**
 * This file is part of the Kolab Server Free/Busy Service
 *
 * @author Thomas Bruederli <bruederli@kolabsys.com>
 *
 * Copyright (C) 2013, Kolab Systems AG <contact@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 */

namespace Kolab\FreeBusy;

/**
 * Implementation of a Free/Busy data source reading from remote URLs through HTTP
 */
class SourceURL extends Source
{
	/**
	 * @see Source::getFreeBusyData()
	 */
	public function getFreeBusyData($user, $extended)
	{
		$config = $this->getUserConfig($user);

		// prepare HTTP stream context
		$context = stream_context_create(array(
			'http' => array(
				'user_agent' => "Kolab Free-Busy Service/0.1.0",
				'timeout'    => 10,
			),
		));

		// set HTTP auth credentials
		if (!empty($config['user'])) {
			stream_context_set_option($context, array(
				'http' => array(
					'header'  => "Authorization: Basic " . base64_encode($config['user'] . ':' . $config['pass']) . "\r\n",
				),
			));
			$config['url'] = self::composeUrl($config);  // re-compose url without user:pass
		}

		$data = @file_get_contents($config['url'], false, $context);

		// log this...
		Logger::get('url')->addInfo("Fetching data from " . $config['url'] . ": " . ($data ? 'OK' : 'FAILED'));

		return $data;
	}

	/**
	 * Compose a full url from the given config (previously extracted with parse_url())
	 */
	private static function composeUrl($config)
	{
		$scheme = isset($config['scheme']) ?       $config['scheme'] . '://' : ''; 
		$host   = isset($config['host'])   ?       $config['host']  : ''; 
		$port   = isset($config['port'])   ? ':' . $config['port']  : ''; 
		$path   = isset($config['path'])   ?       $config['path']  : ''; 
		$query  = isset($config['query'])  ? '?' . $config['query'] : ''; 
		return $scheme . $host . $port . $path . $query;
	}
}
