ALTER TABLE `syncroton_device` ADD `lastping` datetime DEFAULT NULL;
