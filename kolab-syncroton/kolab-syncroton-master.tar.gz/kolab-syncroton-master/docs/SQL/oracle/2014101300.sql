CREATE TABLE "syncroton_relations_state" (
    "device_id" varchar(40) NOT NULL
        REFERENCES "syncroton_device" ("id") ON DELETE CASCADE,
    "folder_id" varchar(40) NOT NULL,
    "synctime" timestamp NOT NULL,
    "data" clob,
    PRIMARY KEY ("device_id", "folder_id", "synctime")
);
