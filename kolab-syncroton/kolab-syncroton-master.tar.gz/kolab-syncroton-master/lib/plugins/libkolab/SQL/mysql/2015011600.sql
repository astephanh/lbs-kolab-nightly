ALTER TABLE `kolab_cache_contact` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_event` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_task` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_journal` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_note` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_file` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_configuration` MODIFY `tags` text NOT NULL;
ALTER TABLE `kolab_cache_freebusy` MODIFY `tags` text NOT NULL;
