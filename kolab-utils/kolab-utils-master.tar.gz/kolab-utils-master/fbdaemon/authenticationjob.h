/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef AUTHENTICATIONJOB_H
#define AUTHENTICATIONJOB_H
#include <kjob.h>
#include <kimap/session.h>
#include <kimap/loginjob.h>
#include <sessionsettings.h>

/**
 * Load credentials from local file
 *
 * ProxyAuth + drop credentials
 * return session
 */
class AuthenticationJob: public KJob
{
    Q_OBJECT
public:
    explicit AuthenticationJob(const SessionSettings &settings, KIMAP::Session *, QObject* parent = 0);
    virtual void start();
    
private slots:
    void onLoginDone(KJob* job);
private:
    KIMAP::Session *mSession;
    SessionSettings mSessionSettings;
    KIMAP::LoginJob::EncryptionMode mRequestedMode;
};

#endif // AUTHENTICATIONJOB_H
