/*
 * Copyright (C) 2014 Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef FBDEAMONTHREAD_H
#define FBDEAMONTHREAD_H

#include "fbdaemonconnection.h"

#include <QObject>
#include <QTcpSocket>

class FbDaemonThread : public QObject
{
    Q_OBJECT

public:
    FbDaemonThread(int socketDescriptor, QObject *parent = 0);
    virtual ~FbDaemonThread();

public slots:
    void start();

signals:
    void error(QAbstractSocket::SocketError socketError);
    void finished(QThread*);
    void newLine(const QByteArray&);

private:
    int socketDescriptor;

    QTcpSocket* tcpSocket;
    FbDaemonConnection* connection;

    QByteArray data;

private slots:
    void onData();
    void onDisconnected();
    void onSocketError(QAbstractSocket::SocketError);

    void onSendData(const QByteArray &);
    void onClose();
};

#endif