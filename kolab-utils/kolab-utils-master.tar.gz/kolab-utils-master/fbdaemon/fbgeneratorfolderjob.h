/*
 *  Copyright (C) 2014 Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef FBGENERATORFOLDERJOB_H
#define FBGENERATORFOLDERJOB_H
#include "kolabjob.h"

#include <kdatetime.h>
#include <kolabfreebusy.h>
#include <kimap/acl.h>

class FBGeneratorFolderTest;

class FBGeneratorFolderJob: public KolabJob
{
    Q_OBJECT
    friend class FBGeneratorFolderTest;
public:
    explicit FBGeneratorFolderJob(const SessionSettings &settings, QString folder, QObject* parent = 0);

    virtual void startWork();
    void setTimeFrame(const KDateTime&, const KDateTime&);
    void setEventFolders(const QStringList &);
    Kolab::Freebusy getFreebusy() const;
    const QString& getFolder() const;
private slots:
    void onMyRightsDone(KJob*);
    void onSetAclDone(KJob*);
    void onGenerateFBDone(KJob*);
    void onResetAclDone(KJob*);

protected:
    virtual void logout();

private:
    void startGenerateFBJob();

    QString mFolder;

    Kolab::Freebusy mFreebusy;
    KIMAP::Acl::Rights rights;
    bool resetRights;

    KDateTime mStartOfTimeFrame;
    KDateTime mEndOfTimeFrame;
};

#endif // FBGENERATORJOB_H
