/*
 * Copyright (C) 2014  Sandro Knauß <knauss@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "fbgeneratorfoldertest.h"
#include "cyrusfakeserver.h"

#include <QTest>
#include <QDebug>
#include <QDir>
#include <iostream>

#include <xmlobject.h>
#include <kolabobject.h>
#include <freebusy.h>
#include <kcalconversion.h>
#include "settings.h"
#include "kolabaccount.h"
#include "fbdaemon/fbgeneratorfolderjob.h"

FBGeneratorFolderTest::FBGeneratorFolderTest(QObject* parent)
    : QObject(parent),
      user("john.doe@example.org")
{
    Settings::instance().setAuthorizationUser("cyrus-admin");
    Settings::instance().setTestMode(true);
    Settings::instance().setPassword("admin");
    Settings::instance().setServerUri("127.0.0.1:5989");
    Settings::instance().setThreshold(10);
    Settings::instance().setTimeframe(60);
    Settings::instance().setAggregatedICalOutputDirectory(QDir::tempPath());
}

Kolab::Freebusy FBGeneratorFolderTest::executeGeneration(const QString &folder, KDateTime start, KDateTime end)
{

    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    sessionSettings.userName = user;

    QObject obj;
    FBGeneratorFolderJob *job = new FBGeneratorFolderJob(sessionSettings, folder , &obj);
    job->setTimeFrame(start, end);
    job->exec();

    return job->getFreebusy();
}

void FBGeneratorFolderTest::executeGenerationError(const QString &folder, KDateTime start, KDateTime end, QString expected)
{

    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    sessionSettings.userName = user;

    QObject obj;
    FBGeneratorFolderJob *job = new FBGeneratorFolderJob(sessionSettings, folder , &obj);
    job->setTimeFrame(start, end);
    job->exec();

    QVERIFY(job->error());
    QCOMPARE(job->errorString(), expected);
}

void FBGeneratorFolderTest::compareFreeBusy(Kolab::Freebusy fb1, Kolab::Freebusy fb2)
{
    QCOMPARE((int)fb1.periods().size(), (int)fb2.periods().size());
    QCOMPARE(fb1.organizer(), fb2.organizer());
    QCOMPARE(fb1.start(), fb2.start());
    QCOMPARE(fb1.end(), fb2.end());
    for (std::size_t i = 0; i < fb1.periods().size(); i++) {
        std::cout << i;
        QCOMPARE(fb1.periods().at(i), fb2.periods().at(i));
    }
}

void FBGeneratorFolderTest::testGenerator()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/normal.log");
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/setrights.log");
    fakeServer.startAndWait();

    KDateTime start;
    KDateTime end;
    Kolab::cDateTime s(2014, 6, 12, 11, 2, 38, true);
    Kolab::cDateTime e(2014, 6, 12, 12, 2, 38, true);
    Kolab::Period period(s, e);
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);

    Kolab::Freebusy fb1 = executeGeneration("shared/Resources/mybeamer@example.com", start, end);
    Kolab::Freebusy fb2 = executeGeneration("shared/Resources/mybeamer@example.com", start, end);

    QCOMPARE((int)fb1.periods().size(), 1);
    QCOMPARE(fb1.organizer(), Kolab::ContactReference(QString("fbdaemon@localhost").toUtf8().constData()));
    QCOMPARE(Kolab::Conversion::toDate(fb1.start()), start);
    QCOMPARE(Kolab::Conversion::toDate(fb1.end()), end);
    QCOMPARE((int)fb1.periods().at(0).periods().size(), 1);
    QCOMPARE(fb1.periods().at(0).periods().at(0), period);
    QVERIFY(!fb1.uid().empty());
    QVERIFY(!fb2.uid().empty());

    compareFreeBusy(fb2, fb1);

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void FBGeneratorFolderTest::testGeneratorEmpty()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/empty.log");
    fakeServer.startAndWait();

    KDateTime start;
    KDateTime end;
    Kolab::cDateTime s(2014, 6, 12, 11, 2, 38, true);
    Kolab::cDateTime e(2014, 6, 12, 12, 2, 38, true);
    Kolab::Period period(s, e);
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);

    Kolab::Freebusy fb1 = executeGeneration("shared/Resources/mybeamer@example.com", start, end);

    QCOMPARE((int)fb1.periods().size(), 0);
    QCOMPARE(fb1.organizer(), Kolab::ContactReference(QString("fbdaemon@localhost").toUtf8().constData()));
    QCOMPARE(Kolab::Conversion::toDate(fb1.start()), start);
    QCOMPARE(Kolab::Conversion::toDate(fb1.end()), end);
    QVERIFY(!fb1.uid().empty());

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void FBGeneratorFolderTest::testFailedNotFound()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/notfound.log");
    fakeServer.startAndWait();

    KDateTime start;
    KDateTime end;
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);

    QString errString = QString("MyRights failed, server replied: A000005 NO Mailbox does not exist ");
    executeGenerationError("shared/Resources/bla@example.com", start, end, errString);

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}

void FBGeneratorFolderTest::testFailedSystemIoError()
{
    CyrusFakeServer fakeServer;
    QDir dir(QLatin1String(SCENARIO_DATA_DIR));
    fakeServer.addScenarioFromFile(dir.path() + "/generatefolder/systemioerror.log");
    fakeServer.startAndWait();

    KDateTime start;
    KDateTime end;
    start.setTime_t(1400604981);
    end.setTime_t(1405788981);

    executeGenerationError("shared/Resources/mega 1000@example.com", start, end, "");

    QVERIFY(fakeServer.isAllScenarioDone());
    fakeServer.quit();
}


void FBGeneratorFolderTest::testSetTimeframe()
{
    SessionSettings sessionSettings = Settings::instance().getSessionSettings();
    QObject obj;
    FBGeneratorFolderJob job(sessionSettings, "", &obj);

    QVERIFY(job.mStartOfTimeFrame.secsTo(KDateTime::currentUtcDateTime()) < 2);  // $now
    QCOMPARE(job.mStartOfTimeFrame.daysTo(job.mEndOfTimeFrame), Settings::instance().getTimeframe()); // $now+$defaultvalue

    KDateTime start;
    KDateTime end;
    start.setTime_t(12345);
    end.setTime_t(67890);
    job.setTimeFrame(start, end);

    QCOMPARE(job.mStartOfTimeFrame, start);
    QCOMPARE(job.mEndOfTimeFrame, end);
}

QTEST_MAIN(FBGeneratorFolderTest)

#include "fbgeneratorfoldertest.moc"
