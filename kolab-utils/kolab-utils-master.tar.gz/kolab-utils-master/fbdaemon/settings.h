/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SETTINGS_H
#define SETTINGS_H
#include <QString>
#include <QVariant>
#include <kimap/loginjob.h>
#include <sessionsettings.h>

class Settings
{
public:
    static Settings &instance()
    {
        static Settings inst;
        return inst;
    }
    void setFile(const QString &file) {mFile = file;};
//     QString file() {return mFile;};

    SessionSettings getSessionSettings() const;


    /**
     * In the form of [imaps://]host[:port]
     * Defaults:
     * imaps: SSL on port 993
     * other: TLSv1 on port 143
     */
    void setServerUri(const QString &server);
    QString getServerUri(qint16 &port) const;
    KIMAP::LoginJob::EncryptionMode getEncryptionMode() const;
    KIMAP::LoginJob::AuthenticationMode getAuthenticationMode() const;

    void setAuthorizationUser(const QString &);
    QString getAuthorizationUser() const;

    void setPassword(const QString &);
    QString getPassword() const;

    //Number of days in f/b
    void setTimeframe(int);
    int getTimeframe() const;
    //Number of days after which the f/b is considered out of date
    void setThreshold(int);
    int getThreshold() const;

    void setAggregatedICalOutputDirectory(const QString &dir);
    QString getAggregatedICalOutputDirectory() const;

    /**Testmode overrides the EncryptionMode to Unencrypted
     * The default value is false
     */
    void setTestMode(bool);
    bool getTestMode() const;
    
private:
    QString getServerUri() const;
    bool usesImplicitSSL() const;
    QVariant getValue(const QString &, const QVariant &) const;
    Settings();
    Settings(const Settings &);
    Settings & operator= (const Settings &);
    QString mFile;

    QString mServerUri;
    QString mAuthorizationUser;
    QString mPassword;
    int mTimeframe;
    int mThreshold;
    QString mAggregatedICalOutputDirectory;
    bool mTestMode;
};

#endif // SETTINGS_H
