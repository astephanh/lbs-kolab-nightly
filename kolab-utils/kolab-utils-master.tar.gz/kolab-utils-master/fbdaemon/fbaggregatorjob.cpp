/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fbaggregatorjob.h"
#include "settings.h"
#include "jobs/probekolabserverjob.h"
#include "jobs/fetchmessagesjob.h"
#include <kdebug.h>
#include <QFile>
#include <QDir>
#include <kolabobject.h>
#include <kolabdefinitions.h>
#include <freebusy.h>
#include <errorhandler.h>
#include <commonconversion.h>

FBAggregatorJob::FBAggregatorJob(const SessionSettings& settings, QObject* parent)
: KolabJob(settings, parent)
{

}

QStringList FBAggregatorJob::requiredFolders()
{
    return QStringList() << KOLAB_FOLDER_TYPE_FREEBUSY;
}

void FBAggregatorJob::startWork()
{
    Debug() << "starting aggregator job for " << mSessionSettings.userName;
    if (mKolabFolders.values(KOLAB_FOLDER_TYPE_FREEBUSY).isEmpty()) {
        kWarning() << "no freebusy folder found";
        setError(KJob::UserDefinedError);
        logout();
        return;
    }
    mFreebusyFolder = mKolabFolders.values(KOLAB_FOLDER_TYPE_FREEBUSY).first();

    FetchMessagesJob *fetchJob = new FetchMessagesJob(mFreebusyFolder, mSession, this);
    connect( fetchJob, SIGNAL(result(KJob*)), this, SLOT(onFetchFBDone(KJob*)) );
    fetchJob->start();
}


void FBAggregatorJob::onFetchFBDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        logout();
        return;
    }
    FetchMessagesJob *fetchJob = qobject_cast<FetchMessagesJob*>( job );
    Q_ASSERT(fetchJob);

    //Filter list and extract organizer from existing objects
    std::vector<Kolab::Freebusy> fbList;
    foreach (const KMime::Message::Ptr &msg, fetchJob->getMessages()) {
        Debug() << "aggregating fb object: " << msg->subject()->asUnicodeString();
//         kDebug() << msg->encodedContent();
        Kolab::KolabObjectReader reader(msg);
        if (reader.getType() != Kolab::FreebusyObject) {
            Warning() << "wrong object type in freebusy folder";
            continue;
        }
        fbList.push_back(reader.getFreebusy());
    }

    if (fbList.empty()) {
        Debug() << "No f/b objects to aggregate";
        logout();
        return;
    }
    std::string organizerName;
    std::string organizerEmail(Kolab::Conversion::toStdString(mSessionSettings.userName));
    const Kolab::Freebusy aggregatedFb = Kolab::FreebusyUtils::aggregateFreeBusy(fbList, organizerEmail, organizerName, true);

//     kDebug() << QString::fromStdString(Kolab::FreebusyUtils::toIFB(aggregatedFb));
    
    QFile file(QDir(Settings::instance().getAggregatedICalOutputDirectory()).absoluteFilePath(QString::fromLatin1("%1.ifb").arg(mSessionSettings.userName.toLower())/*.arg(KDateTime::currentUtcDateTime().toString(KDateTime::ISODate))*/));
    if (!file.open(QIODevice::WriteOnly|QIODevice::Text)) {
        Warning() << "failed to create aggregated f/b file";
        logout();
        return;
    }
    mGeneratedFile = QDir::current().absoluteFilePath(file.fileName());
    QTextStream out(&file);
    out << QString::fromStdString(Kolab::FreebusyUtils::toIFB(aggregatedFb));
    Debug() << "wrote " << mGeneratedFile;
    logout();
}

QString FBAggregatorJob::generatedFile() const
{
    return mGeneratedFile;
}
