/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "settings.h"
#include <qsettings.h>
#include <QFile>
#include <errorhandler.h>

Settings::Settings()
: mTimeframe(-1),
  mThreshold(-1),
  mTestMode(false)
{

}


QVariant Settings::getValue(const QString &key, const QVariant &defaultValue) const
{
    if (!QFile(mFile).exists()) {
        Error() << "Could not find settings file: " << mFile;
        return QVariant();
    }
    Q_ASSERT(QFile(mFile).exists());
    QSettings settings(mFile, QSettings::IniFormat);
    Q_ASSERT(settings.status() == QSettings::NoError);
    settings.beginGroup("kolab");
    const QString backend = settings.value("imap_backend", "cyrus-imap").toString();
    settings.endGroup();

    settings.beginGroup(backend);
    return settings.value(key, defaultValue);
}

void Settings::setServerUri(const QString& server)
{
    mServerUri = server;
}

QString Settings::getServerUri() const
{
    if (!mServerUri.isEmpty()) {
        return mServerUri;
    }
    return getValue("uri", "localhost").toString();
}

bool Settings::usesImplicitSSL() const
{
    return getServerUri().startsWith("imaps:");
}

QString Settings::getServerUri(qint16 &port) const
{
    QString serverUri = getServerUri();
    if (serverUri.contains(QLatin1String("://"))) {
        serverUri.remove(0, serverUri.indexOf(QLatin1String("://"))+3);
    }
    if (serverUri.contains(":")) {
        port = serverUri.section(":", 1, 1).toInt();
        serverUri.truncate(serverUri.indexOf(":"));
    } else {
        if (usesImplicitSSL()) {
            port = 993;
        } else {
            port = 143;
        }
    }
    return serverUri;
}

KIMAP::LoginJob::EncryptionMode Settings::getEncryptionMode() const
{
    if (getTestMode()) {
        qDebug() << "Using unencryptd connection in testmode.";
        return KIMAP::LoginJob::Unencrypted;
    }
    if (usesImplicitSSL()) {
        return KIMAP::LoginJob::AnySslVersion;
    }
    return KIMAP::LoginJob::TlsV1;
}

KIMAP::LoginJob::AuthenticationMode Settings::getAuthenticationMode() const
{
    return KIMAP::LoginJob::Plain;
}

void Settings::setAuthorizationUser(const QString &user)
{
    mAuthorizationUser = user;
}

QString Settings::getAuthorizationUser() const
{
    if (!mAuthorizationUser.isEmpty()) {
        return mAuthorizationUser;
    }
    return getValue("admin_login", "cyrus-admin").toString();
}

void Settings::setPassword(const QString &password)
{
    mPassword = password;
}

SessionSettings Settings::getSessionSettings() const
{
    SessionSettings settings;
    settings.authenticationMode = getAuthenticationMode();
    settings.encryptionMode = getEncryptionMode();
    settings.authorizationName = getAuthorizationUser();
    settings.host = getServerUri(settings.port);
    return settings;
}


QString Settings::getPassword() const
{
    if (!mPassword.isEmpty()) {
        return mPassword;
    }
    return getValue("admin_password", "NoAdminPassword").toString();
}

void Settings::setTestMode(bool testMode)
{
    mTestMode = testMode;
}

bool Settings::getTestMode() const
{
    return mTestMode;
}

void Settings::setTimeframe(int t)
{
    mTimeframe = t;
}

int Settings::getTimeframe() const
{
    if (mTimeframe >= 0) {
        return mTimeframe;
    }
    QSettings settings(mFile, QSettings::IniFormat);
    settings.beginGroup("kolab");
    return settings.value("timeframe", 90).toInt();
}

void Settings::setThreshold(int t)
{
    mThreshold = t;
}

int Settings::getThreshold() const
{
    if (mThreshold >= 0) {
        return mThreshold;
    }
    QSettings settings(mFile, QSettings::IniFormat);
    settings.beginGroup("kolab");
    return settings.value("threshold", 0).toInt();
}

void Settings::setAggregatedICalOutputDirectory(const QString& dir)
{
    mAggregatedICalOutputDirectory = dir;
}

QString Settings::getAggregatedICalOutputDirectory() const
{
    if (!mAggregatedICalOutputDirectory.isEmpty()) {
        return mAggregatedICalOutputDirectory;
    }
    return QLatin1String("/var/lib/kolab-freebusy");
//    QSettings settings(mFile, QSettings::IniFormat);
//    settings.beginGroup("kolab");
//    return settings.value("icalOutputDir", "/var/lib/kolab-freebusy").toString();
}

