/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "kolabjob.h"

#include <QTimer>
#include <kimap/logoutjob.h>
#include <errorhandler.h>

#include "uiproxy.h"
#include "authenticationjob.h"
#include "jobs/probekolabserverjob.h"
#include <jobs/setupkolabfoldersjob.h>
#include <sessionsettings.h>

KolabJob::KolabJob(const SessionSettings &sessionSettings, QObject* parent)
:   KJob(parent),
    mSessionSettings(sessionSettings),
    mSession(0)
{
}

void KolabJob::onSessionStateChanged(KIMAP::Session::State newState, KIMAP::Session::State oldState)
{
//    Debug() << newState;
    if (newState == KIMAP::Session::Disconnected && oldState != KIMAP::Session::Disconnected) {
        Debug() << "lost connenction";
    }
}

void KolabJob::start()
{
    Debug() << "===========================================================";
    Debug() << "starting kolab job: " << mSessionSettings.userName << " on " << mSessionSettings.host << ":" << mSessionSettings.port;

    //Create the session in the same batch as the LoginJob, if we enter the eventloop in between the session might break
    mSession = new KIMAP::Session( mSessionSettings.host, mSessionSettings.port, this );
    mSession->setUiProxy( KIMAP::SessionUiProxy::Ptr(new UiProxy()) );
    QObject::connect( mSession, SIGNAL(stateChanged(KIMAP::Session::State,KIMAP::Session::State)),
                      this, SLOT(onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State)) );
    AuthenticationJob *job = new AuthenticationJob(mSessionSettings, mSession, this);
    QObject::connect( job, SIGNAL(result(KJob*)),
                      this, SLOT(onAuthDone(KJob*)) );
    job->start();
}

QStringList KolabJob::requiredFolders()
{
    return QStringList();
}

void KolabJob::onAuthDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
//    Debug() << "login successful";
    ProbeKolabServerJob *probeJob = new ProbeKolabServerJob(mSession, this);
    QObject::connect(probeJob, SIGNAL(result(KJob*)), this, SLOT(onProbeDone(KJob*)));
    probeJob->start();
}

void KolabJob::onProbeDone(KJob* job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    ProbeKolabServerJob *probeJob = static_cast<ProbeKolabServerJob*>(job);
    mKolabFolders = probeJob->kolabFolders();

    QString rootFolder;
    QStringList toCreate;
    foreach (const QString &folderType, requiredFolders()) {
        if (!mKolabFolders.contains(folderType)) {
            toCreate << folderType;
        }
    }
    if (toCreate.isEmpty()) {
        startWork();
    } else {
        SetupKolabFoldersJob *setupJob = new SetupKolabFoldersJob(probeJob->capabilities(), rootFolder, mSession, this);
        setupJob->setKolabFolders(toCreate);
        connect(setupJob, SIGNAL(result(KJob*)), this, SLOT(onSetupDone(KJob*)));
        setupJob->start();
    }
}

void KolabJob::onSetupDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    startWork();
}

void KolabJob::logout()
{
//    Debug() << "logging out";
    KIMAP::LogoutJob *job = new KIMAP::LogoutJob(mSession);
    connect(job, SIGNAL(result(KJob*)), this, SLOT(onLogoutDone(KJob*)));
    job->start();
}

void KolabJob::onLogoutDone(KJob *job )
{
//    Debug() << "logout done";
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
    }
    mSession->close();
    mSession->deleteLater();
    mSession = 0;
    emitResult();
}
