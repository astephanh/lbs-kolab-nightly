/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

#include "imapupgradejob.h"
#include "kolabformatupgradejob.h"
#include "jobs/probekolabserverjob.h"
#include "jobs/sequentialcompositejob.h"

#include <kimap/loginjob.h>
#include <kimap/logoutjob.h>
#include <kimap/session.h>
#include <kimap/listjob.h>
#include <kimap/getmetadatajob.h>
#include <kimap/sessionuiproxy.h>
#include <kimap/namespacejob.h>
#include <kimap/capabilitiesjob.h>

#include <kmime/kmime_message.h>
#include <errorhandler.h>
#include <kolabdefinitions.h>

class UiProxy: public KIMAP::SessionUiProxy {
  public:
    bool ignoreSslError(const KSslErrorUiData& /*errorData*/) {
        return true; //Necessary due to the untrusted certificate 
    }
};


ImapUpgradeJob::ImapUpgradeJob(QObject* parent): KJob(parent),
m_session(0)
{

}

ImapUpgradeJob::~ImapUpgradeJob()
{

}

void ImapUpgradeJob::setOverrideObjectType(const Kolab::ObjectType type)
{
    m_overrideObjectType = type;
}

void ImapUpgradeJob::setFolderToUpgrade(const QString &folder)
{
    m_folderToUpgrade = folder;
}


void ImapUpgradeJob::connectToAccount(const QString &hostName, qint16 port, const QString &username, const QString &proxyauth, const QString &pw, KIMAP::LoginJob::EncryptionMode encryptionMode, KIMAP::LoginJob::AuthenticationMode authenticationMode)
{
    Debug() << "connecting to: " << hostName << port << username << pw;
    
    m_session = new KIMAP::Session( hostName, port, this );
    m_session->setUiProxy( KIMAP::SessionUiProxy::Ptr(new UiProxy()) );
    
    QObject::connect( m_session, SIGNAL(stateChanged(KIMAP::Session::State,KIMAP::Session::State)),
                      this, SLOT(onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State)) );
    
    KIMAP::LoginJob *loginJob = new KIMAP::LoginJob( m_session );
    if (!proxyauth.isEmpty()) {
        loginJob->setAuthorizationName(proxyauth);
    }
    loginJob->setUserName( username );
    loginJob->setPassword( pw );
    loginJob->setEncryptionMode( encryptionMode );
    if (encryptionMode != KIMAP::LoginJob::Unencrypted) {
        m_requireEncryption = true;
    } else {
        m_requireEncryption = false;
    }
    loginJob->setAuthenticationMode( authenticationMode );
    
    QObject::connect( loginJob, SIGNAL(result(KJob*)),
                      this, SLOT(onLoginDone(KJob*)) );
    loginJob->start();
}

void ImapUpgradeJob::onSessionStateChanged(KIMAP::Session::State newState, KIMAP::Session::State oldState)
{
    Debug() << newState;
    if (newState == KIMAP::Session::Disconnected && oldState != KIMAP::Session::Disconnected) {
        Warning() << "lost connection";
    }
}

void ImapUpgradeJob::onLoginDone( KJob *job )
{
    KIMAP::LoginJob *login = static_cast<KIMAP::LoginJob*>( job );
    
    if ( job->error() ) {
        Error() << job->errorString();
        Error() << "Login failed, job aborted";
        emitResult();
        return;
    }

    if (m_requireEncryption && login->encryptionMode() == KIMAP::LoginJob::Unencrypted) {
        setError(KJob::UserDefinedError);
        setErrorText("failed to encrypt communication");
        Error() << errorString();
        emitResult();
        return;
    }

    if (m_folderToUpgrade.isEmpty()) {
        ProbeKolabServerJob *probeJob = new ProbeKolabServerJob(m_session, this);
        connect(probeJob, SIGNAL(result(KJob*)), this, SLOT(onProbeDone(KJob*)));
        probeJob->start();
    } else {
        SequentialCompositeJob *seqJob = new SequentialCompositeJob(this);
        KolabFormatUpgradeJob *upgradeJob = new KolabFormatUpgradeJob(m_folderToUpgrade, m_session, this);
        upgradeJob->setOverrideObjectType(m_overrideObjectType);
        seqJob->addSubjob(upgradeJob);
        seqJob->addSubjob(new KIMAP::LogoutJob(m_session));
        connect(seqJob, SIGNAL(result(KJob*)), this, SLOT(modifyDone(KJob*)));
        seqJob->start();
    }
}

void ImapUpgradeJob::onProbeDone(KJob* job)
{
    if ( job->error() ) {
        Error() << job->errorString();
        emitResult();
        return;
    }
    ProbeKolabServerJob *capabilitiesJob = qobject_cast<ProbeKolabServerJob*>( job );
    Q_ASSERT(capabilitiesJob);
    
    SequentialCompositeJob *seqJob = new SequentialCompositeJob(this);
    QMultiHash<QString, QString>::const_iterator it;
    QMultiHash<QString, QString>::const_iterator end = capabilitiesJob->kolabFolders().constEnd();
    for (it = capabilitiesJob->kolabFolders().constBegin(); it != end; ++it) {
        if (it.key() == QLatin1String(KOLAB_FOLDER_TYPE_FREEBUSY)) {
            continue;
        }
        seqJob->addSubjob(new KolabFormatUpgradeJob(it.value(), m_session, this));
    }
    //Logout after we're done
    seqJob->addSubjob(new KIMAP::LogoutJob(m_session));
    
    connect(seqJob, SIGNAL(result(KJob*)), this, SLOT(modifyDone(KJob*)));
    seqJob->start();
}

void ImapUpgradeJob::modifyDone( KJob *job )
{
    Debug() << "all done";
    if ( job->error() ) {
        Error() << job->errorString();
    }
    emitResult();
}
