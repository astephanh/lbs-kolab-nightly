/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <QtCore/qcoreapplication.h>
#include <QtCore/QStringList>
#include <QtCore/qfile.h>
#include <kdebug.h>
#include <kcmdlineargs.h>
#include <errorhandler.h>

#include "upgradeutilities.h"
#include "imapupgradejob.h"
#include "kolabutils-version.h"

/**
 * Usage:
 * 
 * IMAP:
 * ./upgradetool -u username -p password imap.server.com
 * 
 * Read mimefile:
 * ./upgradetool -mime complex.ics.mime
 * 
 * Read mimemessage from stdin:
 * cat complex.ics.mime  | ./upgradetool -mime
 * 
 */

int main(int argc, char *argv[])
{
    KCmdLineArgs::init(argc, argv, "upgradetool", "upgradetool",ki18n("upgradetool"),  KOLABUTILS_VERSION);
    
    KCmdLineOptions options;
    options.add("mime", ki18n("Read mime from stdin or file"));
    options.add("u").add("user <loginname>", ki18n("Username for IMAP Account"));
    options.add("y").add("proxyauth <loginname>", ki18n("Username to be used for authentication together with password (optional, works with PLAIN/SASL authentication)"));
    options.add("p").add("password <password>", ki18n("Password for IMAP Account"));
    options.add("P").add("port <port>", ki18n("Port to be used on IMAP Server"), "143");
    options.add("e").add("encrypt <mode>", ki18n("Encryption mode to be used (NONE, TLS, SSL)"), "TLS");
    options.add("f").add("folder <folder>", ki18n("Upgrade only the specified folder"));
    options.add("t").add("type <type>", ki18n("force the type (EVENT, TODO, JOURNAL, CONTACT). Applies only when upgrading a single file or a specific folder."));
    
    options.add("a").add("auth <mode>", ki18n("Authentication mode to be used (PLAIN, LOGIN, CRAMMD5, DIGESTMD5, NTLM, GSSAPI, ANONYMOUS, CLEARTEXT)"), "PLAIN");
//     options.add("f").add
    options.add("+[server/file]", ki18n("IMAP Server/File"));
    KCmdLineArgs::addCmdLineOptions( options );
    QCoreApplication app(argc, argv);
    
    KCmdLineArgs *args = KCmdLineArgs::parsedArgs();

    Kolab::ObjectType overrideType = Kolab::InvalidObject;
    if (args->isSet("type")) {
        const QString &type = args->getOption("type");
        if (type == "EVENT") {
            overrideType = Kolab::EventObject;
        } else if (type == "TODO") {
            overrideType = Kolab::TodoObject;
        } else if (type == "JOURNAL") {
            overrideType = Kolab::JournalObject;
        } else if (type == "CONTACT") {
            overrideType = Kolab::ContactObject;
        } else {
            kWarning() << "unknown type mode";
            return -1;
        }
    }

    QString folderToUpgrade;
    if (args->isSet("folder")) {
        folderToUpgrade = args->getOption("folder");
    }
    
    if (!args->isSet("mime")) {
        if (args->count() == 0) {
            kWarning() << "specify imap server";
            return -1;
        }
        ImapUpgradeJob *upgrader = new ImapUpgradeJob(&app);
        upgrader->setOverrideObjectType(overrideType);
        upgrader->setFolderToUpgrade(folderToUpgrade);
        QObject::connect(upgrader, SIGNAL(result(KJob*)), &app, SLOT(quit()));
        
        KIMAP::LoginJob::EncryptionMode encryptionMode = KIMAP::LoginJob::TlsV1;
        const QString &encrypt = args->getOption("encrypt");
        if (encrypt == "NONE") {
            encryptionMode = KIMAP::LoginJob::Unencrypted;
        } else if (encrypt == "SSL") {
            encryptionMode = KIMAP::LoginJob::AnySslVersion;
        } else if (encrypt == "TLS") {
            encryptionMode = KIMAP::LoginJob::TlsV1;
        } else {
            kWarning() << "unknown encryption mode";
            return -1;
        }

        KIMAP::LoginJob::AuthenticationMode authenticationMode = KIMAP::LoginJob::Plain;
        const QString &auth = args->getOption("auth");
        if (auth == "PLAIN") {
            authenticationMode = KIMAP::LoginJob::Plain;
        } else if (auth == "LOGIN") {
            authenticationMode = KIMAP::LoginJob::Login;
        } else if (auth == "CRAMMD5") {
            authenticationMode = KIMAP::LoginJob::CramMD5;
        } else if (auth == "DIGESTMD5") {
            authenticationMode = KIMAP::LoginJob::DigestMD5;
        } else if (auth == "NTLM") {
            authenticationMode = KIMAP::LoginJob::NTLM;
        } else if (auth == "GSSAPI") {
            authenticationMode = KIMAP::LoginJob::GSSAPI;
        } else if (auth == "ANONYMOUS") {
            authenticationMode = KIMAP::LoginJob::Anonymous;
        } else if (auth == "CLEARTEXT") {
            authenticationMode = KIMAP::LoginJob::ClearText;
        } else {
            kWarning() << "unknown authentication mode";
            return -1;
        }        
        
        upgrader->connectToAccount(args->arg(0), args->getOption("port").toInt(), args->getOption("user"), args->getOption("proxyauth"), args->getOption("password"), encryptionMode, authenticationMode);
        args->clear();
        if (app.exec() || Kolab::ErrorHandler::instance().error() >= Kolab::ErrorHandler::Error) {
            return -1;
        }
        return 0;
    }
    
    QTextStream s(stdout);
    s.setCodec( "UTF-8" );
    QTextStream stream(stdin);
    stream.setCodec( "UTF-8" );
    
    if (args->isSet("mime")) {        
        if (args->count() > 0) {
            const QString &filename = args->arg(0);
            QFile file( filename );
            if (!file.open( QFile::ReadOnly )) {
                kWarning() << "failed to open the file: " << filename;
                return -1;
            }
            const QByteArray data = file.readAll();
            Q_ASSERT( !data.isEmpty() );
            s << Kolab::Upgrade::upgradeMime(data, overrideType);
        } else {
            s << Kolab::Upgrade::upgradeMime(stream.readAll().toUtf8(), overrideType);
        }
    }
    if (Kolab::ErrorHandler::instance().error() >= Kolab::ErrorHandler::Error) {
        return -1;
    }
    return 0;
}
