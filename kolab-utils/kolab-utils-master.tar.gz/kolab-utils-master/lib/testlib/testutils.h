#ifndef TESTUTILS_H
#define TESTUTILS_H

#include <QList>
#include "kolabaccount.h"

struct Folder
{
    Folder(){}
    Folder(const QString &n, Kolab::FolderType type = Kolab::MailType, const QList<Object> &obj = QList<Object>()): objects(obj), name(n), folderType(type){};
    bool operator==(const Folder &other) {
        if (other.name == name) {
            return true;
        }
        return false;
    }
    QList<Object> objects;
    QString name;
    Kolab::FolderType folderType;
};

void fillDefaultFolders(QList<Folder> &folders)
{
    QList<Folder> defaultFolders;
    defaultFolders << Folder("INBOX");
    defaultFolders << Folder("Calendar", Kolab::EventType);
    defaultFolders << Folder("Calendar/Personal Calendar", Kolab::EventType);
    defaultFolders << Folder("Configuration", Kolab::ConfigurationType);
    defaultFolders << Folder("Contacts", Kolab::ContactType);
    defaultFolders << Folder("Drafts");
    defaultFolders << Folder("Freebusy");
    defaultFolders << Folder("Journal", Kolab::JournalType);
    defaultFolders << Folder("Notes", Kolab::NoteType);
    defaultFolders << Folder("Sent");
    defaultFolders << Folder("Tasks", Kolab::TaskType);
    defaultFolders << Folder("Trash");
    foreach (const Folder &folder, defaultFolders) {
        if (!folders.contains(folder)) {
            folders.insert(defaultFolders.indexOf(folder), folder);
        }
    }
    
}

void createFolders(KolabAccount *account, const QList<Folder> &folders)
{
    foreach (Folder folder, folders) {
        if (folders.contains(folder)) {
            folder = folders.value(folders.indexOf(folder));
        }
        account->createFolder(folder.name, folder.folderType);
        foreach(const Object &obj, folder.objects) {
            account->appendObjectSync(obj, folder.name);
        }
    }
}

#endif
