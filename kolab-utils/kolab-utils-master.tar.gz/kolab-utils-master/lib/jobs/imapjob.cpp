/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "imapjob.h"

#include "authenticationjob.h"
#include <jobs/probekolabserverjob.h>
#include <QTimer>
#include <kimap/logoutjob.h>
#include <errorhandler.h>

class UiProxy: public KIMAP::SessionUiProxy {
  public:
    //We need this for ssl errors such as untrusted certificates
    bool ignoreSslError(const KSslErrorUiData& /*errorData*/) {
//        Warning() << "Error during ssl";
        return true;
    }
};

KolabJob::KolabJob(const QString& hostName, qint16 port, const QString& username, QObject* parent)
:   KJob(parent),
    mHostName(hostName),
    mPort(port),
    mUserName(username),
    mSession(0)
{
}

void KolabJob::onSessionStateChanged(KIMAP::Session::State newState, KIMAP::Session::State oldState)
{
//    Debug() << newState;
    if (newState == KIMAP::Session::Disconnected && oldState != KIMAP::Session::Disconnected) {
        Warning() << "lost connenction";
    }
}

void KolabJob::start()
{
    Debug() << "===========================================================";
    Debug() << "starting kolab job: " << mUserName << " on " << mHostName;

    //Create the session in the same batch as the LoginJob, if we enter the eventloop in between the session might break
    mSession = new KIMAP::Session( mHostName, mPort, this );
    mSession->setUiProxy( KIMAP::SessionUiProxy::Ptr(new UiProxy()) );
    QObject::connect( mSession, SIGNAL(stateChanged(KIMAP::Session::State,KIMAP::Session::State)),
                      this, SLOT(onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State)) );
    AuthenticationJob *job = new AuthenticationJob(mUserName, mSession, this);
    QObject::connect( job, SIGNAL(result(KJob*)),
                      this, SLOT(onAuthDone(KJob*)) );
    job->start();
}

QStringList KolabJob::requiredFolders()
{
    return QStringList();
}

void KolabJob::onAuthDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
//    Debug() << "login successful";
    ProbeKolabServerJob *probeJob = new ProbeKolabServerJob(mSession, this);
    probeJob->createDefaultsIfMissing(requiredFolders());
    QObject::connect(probeJob, SIGNAL(result(KJob*)), this, SLOT(onProbeDone(KJob*)));
    probeJob->start();
}

void KolabJob::onProbeDone(KJob* job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    ProbeKolabServerJob *capabilitiesJob = qobject_cast<ProbeKolabServerJob*>( job );
    Q_ASSERT(capabilitiesJob);
    startWork(capabilitiesJob);
}

void KolabJob::logout()
{
//    Debug() << "logging out";
    KIMAP::LogoutJob *job = new KIMAP::LogoutJob(mSession);
    connect(job, SIGNAL(result(KJob*)), this, SLOT(onLogoutDone(KJob*)));
    job->start();
}

void KolabJob::onLogoutDone(KJob *job )
{
//    Debug() << "logout done";
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
    }
    mSession->close();
    mSession->deleteLater();
    mSession = 0;
    emitResult();
}
