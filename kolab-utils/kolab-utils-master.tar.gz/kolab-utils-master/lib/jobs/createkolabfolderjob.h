/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef CREATEKOLABFOLDERJOB_H
#define CREATEKOLABFOLDERJOB_H

#include <kjob.h>

namespace KIMAP {
class Session;
}

class CreateKolabFolderJob : public KJob
{
    Q_OBJECT
public:
    enum MetadataCapability {
        Metadata,
        Annotatemore
    };
    explicit CreateKolabFolderJob(const QString &name, const QByteArray &sharedAnnotation, const QByteArray &privateAnnotation, MetadataCapability cap, KIMAP::Session *session, QObject* parent = 0);
    virtual void start();

    QString folder() const;

    static MetadataCapability capablitiesFromString(const QString &);
    static MetadataCapability capablitiesFromString(const QStringList &);

private slots:
    void onCreateDone(KJob*);
    void onMetadataSetDone(KJob*);
private:
    KIMAP::Session *m_session;
    QString m_name;
    QByteArray m_sharedAnnotation;
    QByteArray m_privateAnnotation;
    MetadataCapability m_metadataCapability;
};

#endif
