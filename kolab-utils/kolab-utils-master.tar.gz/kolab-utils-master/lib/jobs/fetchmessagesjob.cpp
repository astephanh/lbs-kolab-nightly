/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "fetchmessagesjob.h"
#include <kimap/fetchjob.h>
#include <kimap/selectjob.h>

#include <freebusy.h>
#include <kolabobject.h>
#include <errorhandler.h>
#include <kcalconversion.h>

FetchMessagesJob::FetchMessagesJob(const QString &folder, KIMAP::Session *session, QObject* parent)
:   KJob(parent),
    mSession(session),
    mFolder(folder),
    mNumberOfMessagesToFetch(0),
    mTransient(false),
    mBatchSizeLimit(10000000), //in bytes => 10MB
    mBatchSize(0)
{
    mFetchScope.mode = KIMAP::FetchJob::FetchScope::Full;
}

void FetchMessagesJob::setMaxNumberOfMessagesToFetch(int number)
{
    mNumberOfMessagesToFetch = number;
}

void FetchMessagesJob::setUidsToFetch(const QList< qint64 >& uids)
{
    mUidsToFetch = uids;
}

void FetchMessagesJob::setUidsToSkip(const QList< qint64 >& uids)
{
    mUidsToSkip = uids;
}

void FetchMessagesJob::setTransient(bool transient)
{
    mTransient = transient;
}

void FetchMessagesJob::start()
{
    Debug() << "Fetching messages from Mailbox....... " << mFolder;
    KIMAP::SelectJob *select = new KIMAP::SelectJob( mSession );
    select->setMailBox( mFolder );
    select->setOpenReadOnly( true );
    connect( select, SIGNAL(result(KJob*)), this, SLOT(onSelectDone(KJob*)) );
    select->start();
}

KIMAP::FetchJob::FetchScope& FetchMessagesJob::fetchScope()
{
    return mFetchScope;
}

void FetchMessagesJob::onSelectDone(KJob *job)
{
    if ( job->error() ) {
        Warning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }

    KIMAP::SelectJob *select = qobject_cast<KIMAP::SelectJob*>( job );
    Q_ASSERT(select);

    const int messageCount = select->messageCount();
    if (messageCount <= 0) {
        //empty, nothing to do
        Debug() << "no messages available, nothing to do";
        emitResult();
        return;
    }
    setTotalAmount(Files, messageCount);
    Debug() << "Found " << messageCount << " messages";
    
    int messagesToFetch = messageCount;
    if (mNumberOfMessagesToFetch > 0) {
        messagesToFetch = qMin(mNumberOfMessagesToFetch, messageCount);
    }

    KIMAP::FetchJob *fetch = new KIMAP::FetchJob( mSession );
    KIMAP::FetchJob::FetchScope fetchScope;
    fetchScope.mode = KIMAP::FetchJob::FetchScope::Headers;
    fetch->setScope( fetchScope );
    if (!mUidsToFetch.isEmpty()) {
        KIMAP::ImapSet set;
        set.add(mUidsToFetch);
        fetch->setSequenceSet(set);
        fetch->setUidBased(true);
    } else {
        fetch->setSequenceSet(KIMAP::ImapSet(1, messagesToFetch));
    }
    connect( fetch, SIGNAL( headersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                                QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ),
                this, SLOT( onHeadersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                            QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ) );
    connect( fetch, SIGNAL(result(KJob*)),
                this, SLOT(onHeadersFetchDone(KJob*)) );
    fetch->start();
}

void FetchMessagesJob::onHeadersReceived( const QString &/*mailBox*/,
                                           const QMap<qint64, qint64> &uids,
                                           const QMap<qint64, qint64> &sizes,
                                           const QMap<qint64, KIMAP::MessageFlags> &/*flags*/,
                                           const QMap<qint64, KIMAP::MessagePtr> &/*messages*/ )
{
    QMap <qint64, qint64 >::const_iterator it = sizes.begin();
    for (;it != sizes.end(); it++) {
        const qint64 uid = uids.value(it.key());
        if (mUidsToSkip.contains(uid)) {
            continue;
        }
        if ((mBatchSize + it.value()) >= mBatchSizeLimit) {
//             Debug() << "Batch full " << (int)mBatchSize;
            mBatchSize = 0;
            if (!mTempSet.isEmpty()) {
                mBatches.append(mTempSet);
                mTempSet = KIMAP::ImapSet();
            }
        }
        mBatchSize += it.value();
        mTempSet.add(uid);
    }
}

void FetchMessagesJob::onHeadersFetchDone( KJob *job )
{
    if ( job->error() ) {
        Warning() << job->errorString();
    }
    if (!mTempSet.isEmpty()) {
        mBatches.append(mTempSet);
    }
    fetchNextBatch();
}

void FetchMessagesJob::fetchNextBatch()
{
    if (mBatches.isEmpty()) {
        emitResult();
        return;
    }
    const KIMAP::ImapSet batch = mBatches.takeFirst();
    KIMAP::FetchJob *fetch = new KIMAP::FetchJob( mSession );
    fetch->setScope( mFetchScope );
    fetch->setSequenceSet(batch);
    fetch->setUidBased(true);
    connect( fetch, SIGNAL( headersReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                                QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ),
                this, SLOT( onMessagesReceived( QString, QMap<qint64, qint64>, QMap<qint64, qint64>,
                                            QMap<qint64, KIMAP::MessageFlags>, QMap<qint64, KIMAP::MessagePtr> ) ) );
    connect( fetch, SIGNAL(result(KJob*)),
                this, SLOT(onMessagesFetchDone(KJob*)) );
    fetch->start();
}

void FetchMessagesJob::onMessagesReceived( const QString &mailBox,
                                           const QMap<qint64, qint64> &uids,
                                           const QMap<qint64, qint64> &/* sizes */,
                                           const QMap<qint64, KIMAP::MessageFlags> &flags,
                                           const QMap<qint64, KIMAP::MessagePtr> &messages )
{
    QList <Object> objects;
    foreach (qint64 key, uids.keys()) {
        Q_ASSERT(messages.contains(key));
        Q_ASSERT(flags.contains(key));
        if (!mTransient) {
            mMessages.insert(key, messages.value(key));
            mFlags.insert(key, flags.value(key));
            mUids.insert(key, uids.value(key));
        }
        Object obj;
        obj.flags = flags.value(key);
        obj.object = QVariant::fromValue(messages.value(key));
        obj.imapUid = uids.value(key);
        objects << obj;
    }
    emit messagesReceived(mailBox, objects);
    setProcessedAmount(Files, processedAmount(Files)+uids.size());
}

void FetchMessagesJob::onMessagesFetchDone( KJob *job )
{
    if ( job->error() ) {
        Warning() << job->errorString();
    }
    fetchNextBatch();
}

QList< KMime::Message::Ptr > FetchMessagesJob::getMessages() const
{
    return mMessages.values();
}

QList< qint64 > FetchMessagesJob::getImapUids() const
{
    return mUids.values();
}

KIMAP::MessageFlags FetchMessagesJob::getFlags(KMime::Message::Ptr msg) const
{
    return mFlags.value(mMessages.key(msg));
}

qint64 FetchMessagesJob::getImapUid(KMime::Message::Ptr msg) const
{
    return mUids.value(mMessages.key(msg));
}
