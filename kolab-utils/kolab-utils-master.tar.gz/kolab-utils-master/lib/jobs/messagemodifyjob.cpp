/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "messagemodifyjob.h"

#include <kimap/appendjob.h>
#include <kimap/selectjob.h>
#include <kimap/storejob.h>
#include <kdebug.h>

const char* FlagDeleted = "\\Deleted";
const char* FlagRecent = "\\Recent";

MessageModifyJob::MessageModifyJob(const KMime::Message::Ptr& content, const QString &mailbox, const QList<QByteArray> flags, qint64 uid, KIMAP::Session* session, QObject* parent)
:   KCompositeJob(parent),
    m_session(session),
    m_newContent(content),
    m_mailbox(mailbox),
    m_flags(flags),
    m_oldUid(uid)
{
    //The Recent flag is a special case which is not allowed in the append command
    m_flags.removeAll(QByteArray(FlagRecent));
}


void MessageModifyJob::start()
{
//     kDebug() << "append in " << m_mailbox << m_oldUid;
    kDebug() << "Writing item: " << m_oldUid;
    Q_ASSERT(m_newContent.get());
    KIMAP::AppendJob *job = new KIMAP::AppendJob( m_session );
    job->setMailBox( m_mailbox );
    job->setContent( m_newContent->encodedContent( true ) );
    job->setFlags( m_flags );
    
    connect( job, SIGNAL(result(KJob*)),
             this, SLOT(onAppendMessageDone(KJob*)) );
    
    job->start();
}

void MessageModifyJob::onAppendMessageDone( KJob *job )
{
    if ( job->error() ) {
        kWarning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    
    KIMAP::AppendJob *append = qobject_cast<KIMAP::AppendJob*>( job );

    // OK it's a content change, so we've to mark the old version as deleted
    // remember, you can't modify messages in IMAP mailboxes so that's really
    // add+remove all the time.
    
    // APPEND does not require a SELECT, so we could be anywhere right now
    if ( m_session->selectedMailBox() != append->mailBox() ) {
        KIMAP::SelectJob *select = new KIMAP::SelectJob( m_session );
        select->setMailBox( append->mailBox() );
        connect( select, SIGNAL(result(KJob*)),
                 this, SLOT(onPreDeleteSelectDone(KJob*)) );
        select->start();
    } else {
        triggerDeleteJob();
    }
}

void MessageModifyJob::onPreDeleteSelectDone( KJob *job )
{
    if ( job->error() ) {
        kWarning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    triggerDeleteJob();
}

void MessageModifyJob::triggerDeleteJob()
{
    if (m_oldUid < 0) {
        emitResult();
        return;
    }
//     kDebug();
    KIMAP::StoreJob *store = new KIMAP::StoreJob( m_session );
    
    store->setUidBased( true );
    store->setSequenceSet( KIMAP::ImapSet( m_oldUid ) );
    store->setFlags( QList<QByteArray>() << FlagDeleted );
    store->setMode( KIMAP::StoreJob::AppendFlags );
    
    connect( store, SIGNAL(result(KJob*)),
             this, SLOT(onDeleteDone(KJob*)) );
    
    store->start();
}

void MessageModifyJob::onDeleteDone( KJob *job )
{
    if ( job->error() ) {
        kWarning() << job->errorString();
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
//     kDebug() << "delete done";
    emitResult();
}
