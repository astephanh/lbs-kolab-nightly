/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#ifndef SEQUENTIALCOMPOSITEJOB_H
#define SEQUENTIALCOMPOSITEJOB_H

#include <kcompositejob.h>
#include <qqueue.h>

class SequentialCompositeJob : public KCompositeJob
{
    Q_OBJECT
public:
    explicit SequentialCompositeJob(bool abortOnFailure = false, QObject* parent = 0);
    virtual bool addSubjob(KJob* job);
    virtual void start();
protected slots:
    virtual void slotResult( KJob *job );
    void startNext();
private:
    QQueue <KJob*> m_jobs;
    bool mAbortOnFailure;
};

#endif // SEQUENTIALCOMPOSITEJOB_H
