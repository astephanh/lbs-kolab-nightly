/*
    <one line to give the library's name and an idea of what it does.>
    Copyright (C) 2012  Christian Mollekopf <chrigi_1@fastmail.fm>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Affero General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


#include "sequentialcompositejob.h"
#include <kdebug.h>

SequentialCompositeJob::SequentialCompositeJob(bool abortOnFailure, QObject* parent)
: KCompositeJob(parent),
    mAbortOnFailure(abortOnFailure)
{
 
}

bool SequentialCompositeJob::addSubjob(KJob* job)
{
    m_jobs.enqueue(job);
    return KCompositeJob::addSubjob(job);
}

void SequentialCompositeJob::slotResult(KJob* job)
{
    if (job->error()) {
        kWarning() << "Error: " << job->errorString();
        setError(KJob::UserDefinedError);
        setErrorText(job->errorString());
        if (mAbortOnFailure) {
            emitResult();
            return;
        }
    }
    m_jobs.removeAll(job);
    KCompositeJob::slotResult(job);
    if (!m_jobs.isEmpty()) {
//         kDebug() << "trigger next job";
        startNext();
    } else {
//         kDebug() << "all jobs done";
        emitResult();
    }
}

void SequentialCompositeJob::startNext()
{
    KJob *nextJob = m_jobs.head();
    nextJob->start();
}

void SequentialCompositeJob::start()
{
//     kDebug() << "start firstJob";
    if (!m_jobs.isEmpty()) {
        startNext();
//         kDebug() << "start";
    } else {
        kWarning() << "no jobs";
        emitResult();
    }
}
