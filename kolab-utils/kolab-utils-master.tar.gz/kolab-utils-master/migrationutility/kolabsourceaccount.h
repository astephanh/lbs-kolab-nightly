/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef KOLABSOURCEACCOUNT_H
#define KOLABSOURCEACCOUNT_H

#include "imapsourceaccount.h"

class KolabSourceAccount: public IMAPSourceAccount
{
    Q_OBJECT
public:
    explicit KolabSourceAccount(QObject* parent = 0);
    virtual Object convertObject(const Object &object, const QString& folder) const;
    virtual QPair<Kolab::FolderType, QString> translateFolder(const QString& folder);

protected:
    virtual void init();
    Kolab::FolderType getFolderType(const QString &folder) const;

private:
    QMultiHash<QString, QString> mKolabFolders;
};

#endif
