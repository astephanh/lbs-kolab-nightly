/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef GOOGLESOURCEACCOUNT_H
#define GOOGLESOURCEACCOUNT_H

#include <libkgapi2/types.h>
#include <QStringList>

#include "sourceaccount.h"

namespace KGAPI2 {
class Job;
class FetchJob;
}

class GoogleSourceAccount: public SourceAccount
{
public:
    explicit GoogleSourceAccount(QObject* parent = 0);

    void setAccount(const KGAPI2::AccountPtr &account);
    KGAPI2::AccountPtr account();

    void setUser(const QString &username);
    virtual QPair<Kolab::FolderType, QString> translateFolder(const QString& folder);

    virtual KJob *login();
    virtual KJob *logout();

protected:
    KGAPI2::AccountPtr mAccount;
    QString mUser;
private:
    class DummyJob : public KJob {
        virtual void start() {emitResult();}
    };
};

class GoogleContactsSourceAccount: public GoogleSourceAccount
{
public:
    explicit GoogleContactsSourceAccount(QObject* parent = 0);

    virtual QStringList lookupFolderList();
    virtual FetchObjectsJob *fetchObjects(const QString &folder);
};

class GoogleCalendarSourceAccount: public GoogleSourceAccount
{
    Q_OBJECT
public:
    explicit GoogleCalendarSourceAccount(QObject* parent = 0);

    virtual FetchFoldersJob *fetchFolderList();
    virtual FetchObjectsJob *fetchObjects(const QString &folder);
    virtual QPair<Kolab::FolderType, QString> translateFolder(const QString& folder);

private slots:
    void onFetchedCalendars(KJob *job);

private:
    QHash<QString, QString> mCalendarNames;
};

class GoogleTasksSourceAccount: public GoogleSourceAccount
{
    Q_OBJECT
public:
    explicit GoogleTasksSourceAccount(QObject* parent = 0);

    virtual FetchFoldersJob *fetchFolderList();
    virtual FetchObjectsJob *fetchObjects(const QString &folder);
    virtual QPair<Kolab::FolderType, QString> translateFolder(const QString& folder);

private slots:
    void onFetchedTasklists(KJob *job);

private:
    QHash<QString, QString> mTasklists;
};

class GoogleFetchObjectsJob : public FetchObjectsJob
{
    Q_OBJECT
public:
    explicit GoogleFetchObjectsJob(const QString &folder, const KGAPI2::AccountPtr &account, QObject* parent = 0);
    virtual void start();

protected:
    virtual Object getObject(const KGAPI2::ObjectPtr &) = 0;
    virtual KGAPI2::FetchJob *getFetchJob(const KGAPI2::AccountPtr &, const QString &folder) = 0;

private slots:
    void slotFetchJobFinished(KGAPI2::Job *job);

private:
    const KGAPI2::AccountPtr mAccount;
    const QString mCurrentFolder;
};

class GoogleFetchFoldersJob : public FetchFoldersJob
{
    Q_OBJECT
public:
    explicit GoogleFetchFoldersJob(const KGAPI2::AccountPtr &account, QObject* parent = 0);
    virtual void start();
    QHash<QString, QString> mNames;

protected:
    virtual QPair<QString, QString> getFolder(const KGAPI2::ObjectPtr &object) = 0;
    virtual KGAPI2::FetchJob *getFetchJob(const KGAPI2::AccountPtr &account) = 0;

private slots:
    void slotFetchJobFinished(KGAPI2::Job *job);

private:
    const KGAPI2::AccountPtr mAccount;
};

class FetchContactObjectsJob : public GoogleFetchObjectsJob
{
public:
    explicit FetchContactObjectsJob(const KGAPI2::AccountPtr &account, QObject* parent = 0);

protected:
    virtual KGAPI2::FetchJob* getFetchJob(const KGAPI2::AccountPtr &account, const QString& folder);
    virtual Object getObject(const KGAPI2::ObjectPtr &object);
};

class LoginJob : public KJob
{
    Q_OBJECT
public:
    explicit LoginJob(const KGAPI2::AccountPtr &account, QObject* parent = 0);
    virtual void start();

private slots:
    void slotAuthJobFinished(KGAPI2::Job *job);

private:
    KGAPI2::AccountPtr mAccount;
};

class FetchCalendarObjectsJob : public GoogleFetchObjectsJob
{
public:
    explicit FetchCalendarObjectsJob(const QString &mCalendarId, const KGAPI2::AccountPtr &account, QObject* parent = 0);

protected:
    virtual KGAPI2::FetchJob* getFetchJob(const KGAPI2::AccountPtr& , const QString& folder);
    virtual Object getObject(const KGAPI2::ObjectPtr& );
};

class FetchCalendarFoldersJob : public GoogleFetchFoldersJob
{
public:
    explicit FetchCalendarFoldersJob(const KGAPI2::AccountPtr &account, QObject* parent = 0);

protected:
    virtual KGAPI2::FetchJob* getFetchJob(const KGAPI2::AccountPtr& account);
    virtual QPair<QString, QString> getFolder(const KGAPI2::ObjectPtr& object);
};

class FetchTaskObjectsJob : public GoogleFetchObjectsJob
{
public:
    explicit FetchTaskObjectsJob(const QString &mTasklistId, const KGAPI2::AccountPtr &account, QObject* parent = 0);

protected:
    virtual KGAPI2::FetchJob* getFetchJob(const KGAPI2::AccountPtr& , const QString& folder);
    virtual Object getObject(const KGAPI2::ObjectPtr& );
};

class FetchTaskListsJob : public GoogleFetchFoldersJob
{
public:
    explicit FetchTaskListsJob(const KGAPI2::AccountPtr &account, QObject* parent = 0);

protected:
    virtual KGAPI2::FetchJob* getFetchJob(const KGAPI2::AccountPtr& account);
    virtual QPair< QString, QString > getFolder(const KGAPI2::ObjectPtr& object);
};

#endif