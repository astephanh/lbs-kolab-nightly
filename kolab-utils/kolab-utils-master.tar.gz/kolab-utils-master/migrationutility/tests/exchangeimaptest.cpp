/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "exchangeimaptest.h"

#include <QTest>
#include <QDebug>
#include <kolabobject.h>
#include <kabc/vcardconverter.h>
#include <kcalcore/memorycalendar.h>
#include <kcalcore/icalformat.h>
#include "migrationutility/coordinationjob.h"
#include "migrationutility/kolabserver.h"
#include "migrationutility/sourceserver.h"
#include "lib/kolabaccount.h"
#include "lib/testlib/testutils.h"

QPair<Object, Object> ExchangeIMAPTest::createEvent(const QString &uid)
{
    KMime::Message::Ptr msg(new KMime::Message);
    msg->userAgent()->from7BitString( "exchangeimaptest" );
    msg->contentType()->setMimeType( "multipart/mixed" );
    msg->contentType()->setBoundary( KMime::multiPartBoundary() );

    KMime::Content* content = new KMime::Content();
    content->contentType()->setMimeType( "text/calendar" );
    content->contentTransferEncoding()->setEncoding( KMime::Headers::CEbase64 );
    content->contentDisposition()->setDisposition( KMime::Headers::CDattachment );
    KCalCore::Event::Ptr event(new KCalCore::Event());
    event->setUid(uid);
    event->setDtStart(KDateTime::currentUtcDateTime());
    KCalCore::ICalFormat format;
    KCalCore::MemoryCalendar::Ptr calendar(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    calendar->addEvent(event);
    QByteArray decodedContent = format.toString(calendar, QString(), false).toLatin1();
    content->setBody( decodedContent );

    msg->addContent(content);
    msg->assemble();

    Object calObj1;
    calObj1.object = QVariant::fromValue(msg);
    calObj1.flags << QByteArray("\\Seen");

    Object targetObject;
    targetObject.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeEvent(event));
    targetObject.flags << QByteArray("\\Seen");
    return QPair<Object,Object>(calObj1, targetObject);

}

QPair<Object, Object> ExchangeIMAPTest::createTodo(const QString &uid)
{
    KMime::Message::Ptr msg(new KMime::Message);
    msg->userAgent()->from7BitString( "exchangeimaptest" );
    msg->contentType()->setMimeType( "multipart/mixed" );
    msg->contentType()->setBoundary( KMime::multiPartBoundary() );

    KMime::Content* content = new KMime::Content();
    content->contentType()->setMimeType( "text/calendar" );
    content->contentTransferEncoding()->setEncoding( KMime::Headers::CEbase64 );
    content->contentDisposition()->setDisposition( KMime::Headers::CDattachment );
    KCalCore::Todo::Ptr event(new KCalCore::Todo());
    event->setUid(uid);
    event->setDtStart(KDateTime::currentUtcDateTime());
    KCalCore::ICalFormat format;
    KCalCore::MemoryCalendar::Ptr calendar(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
    calendar->addTodo(event);
    QByteArray decodedContent = format.toString(calendar, QString(), false).toLatin1();
    content->setBody( decodedContent );

    msg->addContent(content);
    msg->assemble();

    Object calObj1;
    calObj1.object = QVariant::fromValue(msg);
    calObj1.flags << QByteArray("\\Seen");

    Object targetObject;
    targetObject.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeTodo(event));
    targetObject.flags << QByteArray("\\Seen");
    return QPair<Object,Object>(calObj1, targetObject);

}

QPair<Object, Object> ExchangeIMAPTest::createContact(const QString &name)
{

    KABC::Addressee addressee;
    addressee.setNameFromString(name);

    KMime::Message::Ptr msg(new KMime::Message);
    msg->userAgent()->from7BitString( "exchangeimaptest" );
    msg->contentType()->setMimeType( "multipart/mixed" );
    msg->contentType()->setBoundary( KMime::multiPartBoundary() );

    KMime::Content* content = new KMime::Content();
    content->contentType()->setMimeType( "text/vcard" );
    content->contentTransferEncoding()->setEncoding( KMime::Headers::CEbase64 );
    content->contentDisposition()->setDisposition( KMime::Headers::CDattachment );
    KABC::VCardConverter converter;
    QByteArray decodedContent = converter.createVCard(addressee);
    content->setBody( decodedContent );

    msg->addContent(content);
    msg->assemble();

    Object calObj1;
    calObj1.object = QVariant::fromValue(msg);
    calObj1.flags << QByteArray("\\Seen");

    Object targetObject;
    targetObject.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeContact(addressee));
    targetObject.flags << QByteArray("\\Seen");
    return QPair<Object,Object>(calObj1, targetObject);
}

Object ExchangeIMAPTest::createMail(const QString &subject)
{
    KMime::Message::Ptr msg(new KMime::Message);
    msg->userAgent()->from7BitString( "exchangeimaptest" );
    msg->contentType()->setMimeType( "multipart/mixed" );
    msg->contentType()->setBoundary( KMime::multiPartBoundary() );
    msg->subject()->fromUnicodeString( subject, "utf-8" );
    msg->assemble();
    Object targetObject;
    targetObject.object = QVariant::fromValue(msg);
    targetObject.flags << QByteArray("\\Seen");
    return targetObject;
}

ExchangeIMAPTest::ExchangeIMAPTest(QObject* parent)
    : QObject(parent),
        sourcehost("192.168.122.104"),
        targethost("192.168.122.10"),
        user("john.doe@example.org"),
        admin("cyrus-admin"),
        adminpw("admin"),
        port(143)
{
    folders << Folder("INBOX", Kolab::MailType, QList<Object>() << createMail("subject"));
    folders << Folder("Calendar", Kolab::MailType, QList<Object>() << createEvent("uid1").first);
    folders << Folder("Tasks", Kolab::MailType, QList<Object>() << createTodo("uid2").first);
    folders << Folder("Contacts", Kolab::MailType, QList<Object>() << createContact("John Doe").first);
    folders << Folder("Drafts", Kolab::MailType, QList<Object>() << createMail("subject2"));
    folders << Folder("Sent");
    folders << Folder("Trash");

    targetFolders << Folder("INBOX", Kolab::MailType, QList<Object>() << createMail("subject"));
    targetFolders << Folder("Calendar", Kolab::EventType, QList<Object>() << createEvent("uid1").second);
//         targetFolders << Folder("Calendar/Personal Calendar", Kolab::EventType, QList<Object>() << createEvent("uid2"));
    targetFolders << Folder("Configuration", Kolab::ConfigurationType);
    targetFolders << Folder("Contacts", Kolab::ContactType, QList<Object>() << createContact("John Doe").second);
    targetFolders << Folder("Drafts", Kolab::MailType, QList<Object>() << createMail("subject2"));
    targetFolders << Folder("Journal", Kolab::JournalType);
    targetFolders << Folder("Notes", Kolab::NoteType);
    targetFolders << Folder("Sent");
    targetFolders << Folder("Tasks", Kolab::TaskType, QList<Object>() << createTodo("uid2").second);
    targetFolders << Folder("Trash");
}

ExchangeIMAPTest::~ExchangeIMAPTest(){};

void ExchangeIMAPTest::setupSourceAccount()
{
        KolabServer *kolabServer = new KolabServer(this);
        kolabServer->setHost(sourcehost, port);
        kolabServer->setAdminCredentials(admin, adminpw);
        KolabAccount *account = kolabServer->getAccount(user);
        account->setWipeTargetFolders(true);
        account->cleanAccount();
        createFolders(account, folders);
        QVERIFY(account->logout()->exec());
}

void ExchangeIMAPTest::setupTargetAccount()
{
    //Depending on the test scenario, clear target account
        KolabServer *kolabServer = new KolabServer(this);
        kolabServer->setHost(targethost, port);
        kolabServer->setAdminCredentials(admin, adminpw);
        KolabAccount *account = kolabServer->getAccount(user);
        account->setWipeTargetFolders(true);
        account->cleanAccount();
        QVERIFY(account->logout()->exec());
}

void ExchangeIMAPTest::executeMigration()
{
    QObject obj;
    ExchangeIMAPSourceServer *sourceServer = new ExchangeIMAPSourceServer(&obj);
    sourceServer->setHost(sourcehost, port);
    sourceServer->setAdminCredentials(admin, adminpw);
    sourceServer->setSingleUser(user);

    KolabServer *kolabServer = new KolabServer(&obj);
    kolabServer->setHost(targethost, port);
    kolabServer->setAdminCredentials(admin, adminpw);

    CoordinationJob *job = new CoordinationJob(sourceServer, kolabServer, &obj);
    job->exec();
}

void ExchangeIMAPTest::checkFolders(SourceAccount *account, const QList<Folder> &folders)
{
    const QStringList &receivedFolders = account->lookupFolderList();
    qDebug() << "Received folders: ";
    qDebug() << receivedFolders;
    QStringList::const_iterator recIt = receivedFolders.constBegin();
    QList<Folder>::const_iterator foldersIt = folders.constBegin();
    QCOMPARE(receivedFolders.size(), folders.size());
    for (;foldersIt != folders.constEnd() && recIt != receivedFolders.constEnd(); ++foldersIt, ++recIt) {
        qDebug() << "Folder: " << *recIt;
        QCOMPARE(*recIt, foldersIt->name);
        //TODO Check folder annotations

        const QList<Object> &objects = account->getObjects(foldersIt->name);
        QCOMPARE(objects.size(), foldersIt->objects.size());

        QList<Object>::const_iterator recObjIt = objects.constBegin();
        QList<Object>::const_iterator objIt = foldersIt->objects.constBegin();
        for (;objIt != foldersIt->objects.constEnd() && recObjIt != objects.constEnd(); ++objIt, ++recObjIt) {
            Kolab::KolabObjectReader reader(objIt->object.value<KMime::Message::Ptr>());
            Kolab::ObjectType type = reader.getType();
            if (type == Kolab::EventObject) {
                QCOMPARE(*recObjIt->object.value<KCalCore::Incidence::Ptr>().dynamicCast<KCalCore::Event>(), *Kolab::KolabObjectReader(objIt->object.value<KMime::Message::Ptr>()).getEvent());
            } else if (type == Kolab::TodoObject) {
                QCOMPARE(*recObjIt->object.value<KCalCore::Incidence::Ptr>().dynamicCast<KCalCore::Todo>(), *Kolab::KolabObjectReader(objIt->object.value<KMime::Message::Ptr>()).getTodo());
            } else if (type == Kolab::ContactObject) {
                QCOMPARE(recObjIt->object.value<KABC::Addressee>().name(), Kolab::KolabObjectReader(objIt->object.value<KMime::Message::Ptr>()).getContact().name());
            } else {
//                     QCOMPARE(Kolab::KolabObjectReader(recObjIt->message).getEvent(), *Kolab::KolabObjectReader(objIt->message).getEvent());
            }
            foreach (const QByteArray &flag, objIt->flags) {
                QVERIFY(recObjIt->flags.contains(flag));
            }
        }
    }
}

void ExchangeIMAPTest::checkTargetAccount()
{

    QObject obj;
    KolabSourceServer *kolabSourceServer = new KolabSourceServer(&obj);
    kolabSourceServer->setHost(targethost, port);
    kolabSourceServer->setAdminCredentials(admin, adminpw);
    kolabSourceServer->setSingleUser(user);

    SourceAccount *account = kolabSourceServer->getSourceAccounts(user).first();
    QVERIFY(account->login()->exec());
    checkFolders(account, targetFolders);
    account->logout();
}

void ExchangeIMAPTest::checkSourceAccount()
{
    //If we start clearing the source server on successful migration, check that messages are really gone.
}

void ExchangeIMAPTest::testMigration()
{
    setupSourceAccount();
    setupTargetAccount();
    executeMigration();
    checkTargetAccount();
    checkSourceAccount();
}

QTEST_MAIN( ExchangeIMAPTest )

#include "exchangeimaptest.moc"
