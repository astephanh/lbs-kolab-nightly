/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "migrationscenariotest.h"

#include <QTest>
#include <QDebug>
#include <QFile>
#include <kolabobject.h>
#include "migrationutility/coordinationjob.h"
#include "migrationutility/kolabserver.h"
#include "migrationutility/sourceserver.h"
#include "lib/kolabaccount.h"

MigrationScenarioTest::MigrationScenarioTest(QObject* parent)
    : QObject(parent),
        sourcehost("192.168.122.104"),
        targethost("192.168.122.10"),
        user("john.doe@example.org"),
        admin("cyrus-admin"),
        adminpw("admin"),
        port(143),
        statefilename("/tmp/migrationscenarioteststatefile")
{
}

MigrationScenarioTest::~MigrationScenarioTest(){};

Object MigrationScenarioTest::createEvent(const QString &uid)
{
    Object calObj1;
    KCalCore::Event::Ptr event(new KCalCore::Event());
    event->setUid(uid);
    event->setDtStart(KDateTime::currentUtcDateTime());
    calObj1.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeEvent(event, Kolab::KolabV2, "migrationtest"));
    calObj1.flags << QByteArray("\\Seen");
    return calObj1;
}

KolabAccount *MigrationScenarioTest::getAccount(const QString &host)
{
        KolabServer *kolabServer = new KolabServer(this);
        kolabServer->setHost(host, port);
        kolabServer->setAdminCredentials(admin, adminpw);
        kolabServer->setWipeTargetFolders(true);
        KolabAccount *account = kolabServer->getAccount(user);
        Q_ASSERT(account);
        return account;
}

void MigrationScenarioTest::setupSourceAccount()
{
    KolabAccount *account = getAccount(sourcehost);
    account->cleanAccount();
    fillDefaultFolders(folders);
    createFolders(account, folders);
}

void MigrationScenarioTest::setupTargetAccount()
{
    KolabAccount *account = getAccount(targethost);
    account->cleanAccount();
}

void MigrationScenarioTest::executeMigration(bool useStatefile)
{
    QObject obj;
    //Copy main.cpp
    KolabSourceServer *kolabSourceServer = new KolabSourceServer(&obj);
    kolabSourceServer->setHost(sourcehost, port);
    kolabSourceServer->setAdminCredentials(admin, adminpw);
    kolabSourceServer->setSingleUser(user);
    if (useStatefile) {
        kolabSourceServer->setStatefile(statefilename);
    }

    KolabServer *kolabServer = new KolabServer(&obj);
    kolabServer->setHost(targethost, port);
    kolabServer->setAdminCredentials(admin, adminpw);

    CoordinationJob *job = new CoordinationJob(kolabSourceServer, kolabServer, &obj);
    QVERIFY(job->exec());
}

void MigrationScenarioTest::checkFolders(SourceAccount *account, const QList<Folder> &folders)
{
    Q_ASSERT(account);
    const QStringList &receivedFolders = account->lookupFolderList();
    QStringList::const_iterator recIt = receivedFolders.constBegin();
    QList<Folder>::const_iterator foldersIt = folders.constBegin();
    QCOMPARE(receivedFolders.size(), folders.size());
    for (;foldersIt != folders.constEnd() && recIt != receivedFolders.constEnd(); ++foldersIt, ++recIt) {
        qDebug() << "Folder: " << *recIt;
        QCOMPARE(*recIt, foldersIt->name);
        //TODO Check folder annotations
        const QList<Object> &objects = account->getObjects(foldersIt->name);
        QCOMPARE(objects.size(), foldersIt->objects.size());

        QList<Object>::const_iterator recObjIt = objects.constBegin();
        QList<Object>::const_iterator objIt = foldersIt->objects.constBegin();
        for (;objIt != foldersIt->objects.constEnd() && recObjIt != objects.constEnd(); ++objIt, ++recObjIt) {
            QVERIFY(recObjIt->object.canConvert<KCalCore::Incidence::Ptr>());
            QVERIFY(objIt->object.canConvert<KMime::Message::Ptr>());
            QCOMPARE(*recObjIt->object.value<KCalCore::Incidence::Ptr>().dynamicCast<KCalCore::Event>(), *Kolab::KolabObjectReader(objIt->object.value<KMime::Message::Ptr>()).getEvent());
            foreach (const QByteArray &flag, objIt->flags) {
                QVERIFY(recObjIt->flags.contains(flag));
            }
        }
    }
}

void MigrationScenarioTest::checkTargetAccount()
{
    QObject obj;
    KolabSourceServer *kolabSourceServer = new KolabSourceServer(&obj);
    kolabSourceServer->setHost(targethost, port);
    kolabSourceServer->setAdminCredentials(admin, adminpw);
    kolabSourceServer->setSingleUser(user);

    SourceAccount *account = kolabSourceServer->getSourceAccounts(user).first();
    QVERIFY(account->login()->exec());
    checkFolders(account, folders);
    QVERIFY(account->logout()->exec());
}

void MigrationScenarioTest::checkSourceAccount()
{
    //If we start clearing the source server on successful migration, check that messages are really gone.
}

void MigrationScenarioTest::init()
{
    QFile file(statefilename);
    file.remove();
    folders.clear();
}

void MigrationScenarioTest::testMigration()
{
    folders << Folder("Calendar", Kolab::EventType, QList<Object>() << createEvent("uid1"));
    folders << Folder("Calendar/Personal Calendar", Kolab::EventType, QList<Object>() << createEvent("uid2"));
    setupSourceAccount();
    setupTargetAccount();
    executeMigration();
    checkTargetAccount();
    checkSourceAccount();
}

void MigrationScenarioTest::testMassMigration()
{
    QTime time;
    time.start();
    QList<Object> events;
    for(int i = 0; i < 1000; i++) {
        events << createEvent(QString("uid%1").arg(i));
    }
    folders << Folder("Calendar", Kolab::EventType, events);
    setupSourceAccount();
    qDebug() << "setup done " << time.elapsed()/1000.0;
    time.start();
    setupTargetAccount();
    executeMigration();
    qDebug() << "migration done " << time.elapsed()/1000.0;
    checkTargetAccount();
    checkSourceAccount();
}

void MigrationScenarioTest::testLargeAttachments()
{
    QTime time;
    time.start();

    QByteArray data;
    data.fill('x', 10000000);
    KCalCore::Attachment::Ptr attachment(new KCalCore::Attachment(data.toBase64(), "text/plain"));

    QList<Object> events;
    Object calObj1;
    KCalCore::Event::Ptr event(new KCalCore::Event());
    event->setUid("uid1");
    event->setDtStart(KDateTime::currentUtcDateTime());
    event->addAttachment(attachment);
    calObj1.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeEvent(event, Kolab::KolabV3, "migrationtest"));
    calObj1.flags << QByteArray("\\Seen");
    events << calObj1;

    Object calObj2;
    KCalCore::Event::Ptr event2(new KCalCore::Event());
    event2->setUid("uid2");
    event2->setDtStart(KDateTime::currentUtcDateTime());
    event2->addAttachment(attachment);
    calObj2.object = QVariant::fromValue(Kolab::KolabObjectWriter::writeEvent(event2, Kolab::KolabV3, "migrationtest"));
    calObj2.flags << QByteArray("\\Seen");
    events << calObj2;


    folders << Folder("Calendar", Kolab::EventType, events);
    setupSourceAccount();
    qDebug() << "setup done " << time.elapsed()/1000.0;
    time.start();
    setupTargetAccount();
    executeMigration();
    qDebug() << "migration done " << time.elapsed()/1000.0;
    checkTargetAccount();
    checkSourceAccount();
}

void MigrationScenarioTest::testStatefile()
{
    QList<Object> events;
    events << createEvent(QString("uid1"));
    events << createEvent(QString("uid2"));
    const Object event3 = createEvent(QString("uid3"));
    events << event3;
    folders << Folder("Calendar", Kolab::EventType, events);
    setupSourceAccount();
    setupTargetAccount();
    executeMigration(true);

    //Check statefile
    StateFile statefile(statefilename, user);
    QList<qint64> migratedUids = statefile.getMigratedUids("Calendar");
    QCOMPARE(migratedUids.size(), 3);

    //Remove one event from statefile
    qint64 toMigrate = migratedUids.takeLast();
    statefile.setMigratedUids("Calendar", migratedUids);

    //Redo migration, this time with the statefile
    setupTargetAccount();
    executeMigration(true);
    StateFile statefile2(statefilename, user);
    migratedUids = statefile2.getMigratedUids("Calendar");
    QCOMPARE(migratedUids.size(), 3);
    QVERIFY(migratedUids.contains(toMigrate));

    //onyl one event was migrated
    folders.clear();
    folders << Folder("Calendar", Kolab::EventType, QList<Object>() << event3);
    fillDefaultFolders(folders);
    checkTargetAccount();
}

QTEST_MAIN( MigrationScenarioTest )

#include "migrationscenariotest.moc"
