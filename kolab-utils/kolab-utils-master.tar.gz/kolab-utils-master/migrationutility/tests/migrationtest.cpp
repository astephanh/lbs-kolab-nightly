/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "migrationtest.h"

#include <QTest>
#include "coordinationjob.h"
#include "sourceserver.h"
#include "kolabserver.h"
#include "migrateuserjob.h"
#include <kolabaccount.h>

void MigrationTest::testUsersProcessed()
{
    TestServer *server = new TestServer(this);
    KolabServer *kolabServer = new KolabServer(this);
    kolabServer->setDryRun(true);
    CoordinationJob *job = new CoordinationJob(server, kolabServer, this);
    QVERIFY(job->exec());
    QVERIFY(server->mUsers.isEmpty());
}

void MigrationTest::testFoldersProcessed()
{
    TestAccount *testSourceAccount = new TestAccount(this);
    KolabAccount *kolabTargetAccount = new KolabAccount(this);
    kolabTargetAccount->setDryRun(true);
    MigrateUserJob *job = new MigrateUserJob(QList<SourceAccount*>() << testSourceAccount, kolabTargetAccount, this);
    QVERIFY(job->exec());
    QVERIFY(testSourceAccount->mFolderList.isEmpty());
}

QTEST_MAIN( MigrationTest )

#include "migrationtest.moc"