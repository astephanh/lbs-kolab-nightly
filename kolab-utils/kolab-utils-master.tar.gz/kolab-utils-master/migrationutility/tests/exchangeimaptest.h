/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef EXCHANGEIMAPTEST_H
#define EXCHANGEIMAPTEST_H

#include <QObject>
#include "testlib/testutils.h"

class SourceAccount;

/**
 * This test simulates an entier migration scenario.
 *
 * It requires two Kolab Servers, with all the required users already setup (ideally two local virtual machines, which are used for testing only)
 * So this is really a complex integration test, which involves all parts of the system, and not a unittest which has to be executed all the time.
 * On the other hand it should come quite close to a real world migration scenario and can also show problems with specific imap servers.
 */
class ExchangeIMAPTest: public QObject
{
    Q_OBJECT
public:
    explicit ExchangeIMAPTest(QObject* parent = 0);
    virtual ~ExchangeIMAPTest();

private slots:
    void testMigration();

private:
    void setupSourceAccount();
    void setupTargetAccount();
    void executeMigration();
    void checkFolders(SourceAccount *account, const QList<Folder> &folders);
    void checkTargetAccount();
    void checkSourceAccount();

    QPair<Object, Object> createEvent(const QString &uid);
    QPair<Object, Object> createTodo(const QString &uid);
    QPair<Object, Object> createContact(const QString &name);
    Object createMail(const QString &subject);

    QString sourcehost;
    QString targethost;
    QString user;
    QString admin;
    QString adminpw;
    qint16 port;
    QList<Folder> folders;
    QList<Folder> targetFolders;
};

#endif
