/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "migratefolderjob.h"
#include "sourceaccount.h"
#include "kolabaccount.h"
#include <errorhandler.h>
#include <qdebug.h>

MigrateFolderJob::MigrateFolderJob(const QString &folder, SourceAccount* sourceAccount, KolabAccount *kolabAccount, QObject* parent)
:   KJob(parent),
    mSourceAccount(sourceAccount),
    mKolabAccount(kolabAccount),
    mFolder(folder),
    mRunningAppendJobs(0),
    mFetchDone(false)
{

}

void MigrateFolderJob::start()
{
    QMetaObject::invokeMethod(this, "doStart", Qt::QueuedConnection);
}

void MigrateFolderJob::doStart()
{
    Debug() << "migrating " << mFolder;
    const QPair<Kolab::FolderType, QString> &targetFolder = mSourceAccount->translateFolder(mFolder);
    mTargetFolder = mKolabAccount->applyTargetFolderTransformations(targetFolder.second);
    mKolabAccount->createFolder(mTargetFolder, targetFolder.first);

    FetchObjectsJob *fetchJob = mSourceAccount->fetchObjects(mFolder);
    if (!fetchJob) {
        setErrorText("Invalid FetchMessagesJob");
        setError(KJob::UserDefinedError);
        emitResult();
        return;
    }
    connect(fetchJob, SIGNAL(objectsReceived(QString, QList<Object>)), this, SLOT(processMessages(QString, QList<Object>)));
    connect(fetchJob, SIGNAL(result(KJob*)), this, SLOT(fetchJobFinished(KJob*)));
    fetchJob->start();
}

void MigrateFolderJob::fetchJobFinished(KJob *job)
{
    if (job->error()) {
        setErrorText("Fetch job failed");
        setError(KJob::UserDefinedError);
        Warning() << job->errorString();
    }
    mFetchDone = true;
    checkDone();
}

void MigrateFolderJob::processMessages(const QString &folder, const QList<Object> &messages)
{
    foreach (const Object &message, messages) {
        KJob *appendJob = mKolabAccount->appendObject(mSourceAccount->convertObject(message, folder), mTargetFolder);
        if (!appendJob) {
            continue;
        }
        appendJob->setProperty("appendedObject", QVariant::fromValue(message));
        connect(appendJob, SIGNAL(result(KJob*)), this, SLOT(appendJobFinished(KJob*)));
        mRunningAppendJobs++;
        appendJob->start();
    }
}

void MigrateFolderJob::appendJobFinished(KJob *job)
{
    mRunningAppendJobs--;
    if (job->error()) {
        setErrorText("Append job failed");
        setError(KJob::UserDefinedError);
        Warning() << job->errorString();
    } else {
        mSourceAccount->recordSuccessfulMigration(job->property("appendedObject").value<Object>(), mFolder);
    }
    checkDone();
}

void MigrateFolderJob::checkDone()
{
    if (mRunningAppendJobs <= 0 && mFetchDone) {
        emitResult();
    }
}
