/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef SOURCESERVER_H
#define SOURCESERVER_H

#include <kimap/session.h>
#include <kimap/loginjob.h>
#include <qsharedpointer.h>
#include <QStringList>
#include "sourceaccount.h"
#include <kolabdefinitions.h>

/**
 * Job interface to retrieve users from a server.
 */
class UserListJob: public KJob
{
    Q_OBJECT
public:
    explicit UserListJob(QObject* parent = 0);
    virtual QStringList getUserList() const = 0;
};

class FixedUserListJob: public UserListJob
{
    Q_OBJECT
public:
    explicit FixedUserListJob(const QStringList &userList, QObject* parent = 0);
    virtual void start();
    virtual QStringList getUserList() const;
   
private slots:
    void doEmitResult();

private:
    QStringList mUserList;
};



/**
 * The source server represents a server with user accounts that need to be migrated.
 *
 * The server can support multiple access protocols per user, that are each represented by a source account.
 */
class SourceServer: public QObject
{
    Q_OBJECT
public:
    explicit SourceServer(QObject* parent = 0);
    QList<SourceAccount*> getSourceAccounts(const QString &user);
    UserListJob *listUsers();
    void setSingleUser(const QString &);
    void setStatefile(const QString &);

    /**
     * Specify a list of regex to ignore source folders.
     */
    void setIgnoredFolders(const QStringList &);
    QStringList ignoredFolders() const;

    void setObjectTypesToMigrate(const QStringList &);
protected:
    virtual QList<SourceAccount*> getSourceAccountsImpl(const QString &user) = 0;
    /**
     * Reeimplement to retrieve a user list from the server.
     * Note that the retrieved username is used to login to the users account on the source server.
     */
    virtual UserListJob *retrieveUserList();

    bool shouldMigrateType(const QString &type) const;
    QStringList mExplicitUsers;
    QString mStatefile;
private:
    QStringList mIgnoredFolders;
    QStringList mObjectTypesToMigrate;
};


class TestServer: public SourceServer
{
    Q_OBJECT
public:
    explicit TestServer(QObject* parent = 0);
    
    QStringList mUsers;
protected:
    virtual UserListJob *retrieveUserList();
    virtual QList< SourceAccount* > getSourceAccountsImpl(const QString& user);
};

class IMAPConnectionSettings {
public:
    IMAPConnectionSettings(const QString &username, const QString &pw, KIMAP::LoginJob::EncryptionMode encryptionMode, KIMAP::LoginJob::AuthenticationMode authenticationMode)
    : mUsername(username), mPassword(pw), mEncryptionMode(encryptionMode), mAuthenticationMode(authenticationMode)
    {}
    QString username() const { return mUsername; }
    QString password() const { return mPassword; }
    KIMAP::LoginJob::EncryptionMode encryptionMode() const { return mEncryptionMode; }
    KIMAP::LoginJob::AuthenticationMode authenticationMode() const { return mAuthenticationMode; }
private:
    const QString mUsername;
    const QString mPassword;
    const KIMAP::LoginJob::EncryptionMode mEncryptionMode;
    const KIMAP::LoginJob::AuthenticationMode mAuthenticationMode;
};

class IMAPUserListJob: public UserListJob
{
    Q_OBJECT
public:
    explicit IMAPUserListJob(const QString &host, qint16 port, const IMAPConnectionSettings &settings, QObject* parent = 0);
    virtual ~IMAPUserListJob();
    virtual void start();
    virtual QStringList getUserList() const;

private slots:
    void onLoginDone(KJob*);
    void onUserListJobDone(KJob*);
    void onLogoutDone(KJob*);

private:
    KIMAP::Session *mSession;
    const IMAPConnectionSettings mConnectionSettings;
    QStringList mUserList;
};

class IMAPSourceServer: public SourceServer
{
    Q_OBJECT
public:
    explicit IMAPSourceServer(QObject* parent = 0);

    void setHost(const QString &host, qint16 port);
    void setAdminCredentials(const QString &username, const QString &pw);
    void setEncryption(KIMAP::LoginJob::EncryptionMode);
    void setAuthentication(KIMAP::LoginJob::AuthenticationMode);
protected:
    virtual QList< SourceAccount* > getSourceAccountsImpl(const QString& user);
    virtual UserListJob *retrieveUserList();
    KIMAP::Session *mSession;
    QString mHost;
    int mPort;
    QString mUsername;
    QString mPw;
    KIMAP::LoginJob::EncryptionMode mEncryptionMode;
    KIMAP::LoginJob::AuthenticationMode mAuthenticationMode;
};

class KolabSourceServer: public IMAPSourceServer
{
    Q_OBJECT
public:
    explicit KolabSourceServer(QObject* parent = 0);
    
protected:
    virtual QList< SourceAccount* > getSourceAccountsImpl(const QString& user);
};

class ExchangeIMAPSourceServer: public IMAPSourceServer
{
    Q_OBJECT
public:
    explicit ExchangeIMAPSourceServer(QObject* parent = 0);
    
protected:
    virtual QList< SourceAccount* > getSourceAccountsImpl(const QString& user);
};

#endif // SOURCESERVER_H
