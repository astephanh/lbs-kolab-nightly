/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "imapsourceaccount.h"

#include <jobs/fetchmessagesjob.h>
#include <jobs/probeimapserverjob.h>
#include <sessionfactory.h>
#include <kimap/session.h>
#include <kimap/listjob.h>
#include <kimap/logoutjob.h>
#include <kimap/capabilitiesjob.h>
#include <kimap/namespacejob.h>
#include <errorhandler.h>

FetchIMAPObjectsJob::FetchIMAPObjectsJob(FetchMessagesJob *fetchJob, QObject *parent)
: FetchObjectsJob(parent), mFetchMessagesJob(fetchJob)
{
}

void FetchIMAPObjectsJob::start()
{
    connect(mFetchMessagesJob, SIGNAL(messagesReceived(QString,QList<Object>)), this, SIGNAL(objectsReceived(QString,QList<Object>)));
    connect(mFetchMessagesJob, SIGNAL(result(KJob*)), this, SLOT(onJobDone(KJob*)));
    mFetchMessagesJob->start();
}

void FetchIMAPObjectsJob::onJobDone(KJob *job)
{
    if (job->error()) {
        setError(job->error());
        setErrorText(job->errorString());
    }
    emitResult();
}


IMAPSourceAccount::IMAPSourceAccount(QObject* parent)
:   SourceAccount(parent),
    mSession(0)
{

}

IMAPSourceAccount::~IMAPSourceAccount()
{
    if (mSession) {
        mSession->close();
        mSession->deleteLater();
    }
}

QPair<Kolab::FolderType, QString> IMAPSourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(Kolab::MailType, folder);
}

void IMAPSourceAccount::init()
{
    ProbeIMAPServerJob *probeJob = new ProbeIMAPServerJob(mSession, this);
    probeJob->exec();
    mPersonalNamespaces = probeJob->personalNamespace();
}

QStringList IMAPSourceAccount::lookupFolderList()
{
    Q_ASSERT(mSession);
//     Debug() << "lookupFolderList" << mSession->state();

    init();

    mMailboxes.clear();

    KIMAP::ListJob *listJob = new KIMAP::ListJob(mSession);
    listJob->setOption(KIMAP::ListJob::IncludeUnsubscribed);
    listJob->setQueriedNamespaces(mPersonalNamespaces);
    QObject::connect( listJob, SIGNAL(mailBoxesReceived(QList<KIMAP::MailBoxDescriptor>,QList<QList<QByteArray> >)),
                      this, SLOT(mailBoxesReceived(QList<KIMAP::MailBoxDescriptor>,QList<QList<QByteArray> >)));
    listJob->exec();
    Debug() << "found " << mMailboxes.size();

    QStringList mailboxes;
    foreach (const KIMAP::MailBoxDescriptor &descriptor, mMailboxes) {
        mailboxes.append(descriptor.name);
    }
    return mailboxes;
}

void IMAPSourceAccount::mailBoxesReceived(const QList<KIMAP::MailBoxDescriptor> &descriptors, const QList< QList< QByteArray > > &/* flags */)
{
    mMailboxes.append(descriptors);
}

void IMAPSourceAccount::recordSuccessfulMigration(const QList<Object> &objects, const QString &folder)
{
    if (mStatefile.isValid()) {
        QList<qint64> uids;
        foreach (const Object &obj, objects) {
            uids << obj.imapUid;
        }
        mStatefile.appendMigratedUids(folder, uids);
    }
}

FetchObjectsJob* IMAPSourceAccount::fetchObjects(const QString& folder)
{
    FetchMessagesJob *fetchJob = new FetchMessagesJob(folder, mSession, this);
    fetchJob->setTransient(true);
    if (mStatefile.isValid()) {
        fetchJob->setUidsToSkip(mStatefile.getMigratedUids(folder));
    }
    return new FetchIMAPObjectsJob(fetchJob, this);
}

Object IMAPSourceAccount::convertObject(const Object& object, const QString& /*folder*/) const
{
    return object;
}

QList<qint64> IMAPSourceAccount::getImapUids(const QString &folder)
{
    FetchMessagesJob *fetchJob = new FetchMessagesJob(folder, mSession, this);
    fetchJob->fetchScope().mode = KIMAP::FetchJob::FetchScope::Headers;
    fetchJob->exec();
    return fetchJob->getImapUids();
}

KIMAP::Session* IMAPSourceAccount::getSession()
{
    Q_ASSERT(mSession);
    return mSession;
}

void IMAPSourceAccount::prepareConnection(QString host, qint16 port, const QString& authorizationName, const QString& userName, const QString& password, KIMAP::LoginJob::EncryptionMode encryptionMode, KIMAP::LoginJob::AuthenticationMode authenticationMode)
{
    mHost = host;
    mPort = port;
    mAuthorizationName = authorizationName;
    mUsername = userName;
    mPw = password;
    mEncryptionMode = encryptionMode;
    mAuthenticationMode = authenticationMode;
}

void IMAPSourceAccount::onSessionStateChanged(KIMAP::Session::State oldstate, KIMAP::Session::State newstate)
{
    if (newstate == KIMAP::Session::Disconnected) {
        Debug() << "session disconnected";
    }
}

KJob *IMAPSourceAccount::login()
{
    mSession = createSession(mHost, mPort, this);
    QObject::connect(mSession, SIGNAL(stateChanged(KIMAP::Session::State,KIMAP::Session::State)),
                      this, SLOT(onSessionStateChanged(KIMAP::Session::State,KIMAP::Session::State)) );

    KIMAP::LoginJob *loginJob = new KIMAP::LoginJob(mSession);
    if (mAuthorizationName != mUsername) {
        loginJob->setAuthorizationName(mAuthorizationName);
    }
    loginJob->setUserName(mUsername);
    loginJob->setPassword(mPw);
    loginJob->setEncryptionMode(mEncryptionMode);
    loginJob->setAuthenticationMode(mAuthenticationMode);
    return loginJob;
}

KJob *IMAPSourceAccount::logout()
{
    return new KIMAP::LogoutJob(mSession);
}