/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "sourceserver.h"
#include <jobs/getuserlistjob.h>
#include "sessionfactory.h"
#include <kimap/listjob.h>
#include <kimap/logoutjob.h>
#include <commonconversion.h>
#include <errorhandler.h>
#include "kolabsourceaccount.h"
#include "exchangesourceaccount.h"


UserListJob::UserListJob(QObject* parent)
:   KJob(parent)
{

}

FixedUserListJob::FixedUserListJob(const QStringList& userList, QObject* parent)
:   UserListJob(parent),
    mUserList(userList)
{

}

void FixedUserListJob::start()
{
    QMetaObject::invokeMethod(this, "doEmitResult", Qt::QueuedConnection);
}

void FixedUserListJob::doEmitResult()
{
    emitResult();
}

QStringList FixedUserListJob::getUserList() const
{
    return mUserList;
}


SourceServer::SourceServer(QObject* parent): QObject(parent)
{

}

QList<SourceAccount*> SourceServer::getSourceAccounts(const QString &user)
{
    const QList<SourceAccount*> accounts = getSourceAccountsImpl(user);
    foreach (SourceAccount * account, accounts) {
        account->setIgnoredFolders(mIgnoredFolders);
    }
    return accounts;
}

UserListJob *SourceServer::listUsers()
{
    if (!mExplicitUsers.isEmpty()) {
        return new FixedUserListJob(mExplicitUsers, this);
    }
    return retrieveUserList();
}

void SourceServer::setSingleUser(const QString &user)
{
    mExplicitUsers.append(user);
}

UserListJob *SourceServer::retrieveUserList()
{
    return 0;
}

void SourceServer::setStatefile(const QString &statefile)
{
    mStatefile = statefile;
}

void SourceServer::setIgnoredFolders(const QStringList &ignoredFolders)
{
    Debug() << "Skipping source folders: " << ignoredFolders;
    mIgnoredFolders = ignoredFolders;
}

QStringList SourceServer::ignoredFolders() const
{
    return mIgnoredFolders;
}

void SourceServer::setObjectTypesToMigrate(const QStringList &types)
{
    Debug() << "Migrating only types: " << types;
    mObjectTypesToMigrate = types;
}

bool SourceServer::shouldMigrateType(const QString &type) const
{
    if (mObjectTypesToMigrate.isEmpty()) {
        return true;
    }
    return mObjectTypesToMigrate.contains(type, Qt::CaseInsensitive);
}


TestServer::TestServer(QObject* parent)
:   SourceServer(parent)
{
    mUsers << QLatin1String("user1");
    mUsers << QLatin1String("user2");
    mUsers << QLatin1String("user3");
}

QList<SourceAccount*> TestServer::getSourceAccountsImpl(const QString& user)
{
    Q_UNUSED(user);
    Q_ASSERT(mUsers.removeAll(user) == 1);
    return QList<SourceAccount*>() << new TestAccount(this);
}

UserListJob *TestServer::retrieveUserList()
{
    return new FixedUserListJob(mUsers, this);
}

//---------------------------------------------------------------------------

IMAPUserListJob::IMAPUserListJob(const QString &host, qint16 port, const IMAPConnectionSettings &settings, QObject* parent)
:   UserListJob(parent),
    mSession(createSession(host, port, this)),
    mConnectionSettings(settings)
{
}

IMAPUserListJob::~IMAPUserListJob()
{
    if (mSession) {
        mSession->close();
        mSession->deleteLater();
    }
}

void IMAPUserListJob::start()
{
    KIMAP::LoginJob *loginJob = new KIMAP::LoginJob(mSession);
    loginJob->setUserName(mConnectionSettings.username());
    loginJob->setPassword(mConnectionSettings.password());
    loginJob->setEncryptionMode(mConnectionSettings.encryptionMode());
    loginJob->setAuthenticationMode(mConnectionSettings.authenticationMode());
    connect(loginJob, SIGNAL(result(KJob*)), this, SLOT(onLoginDone(KJob*)));
    loginJob->start();
}

void IMAPUserListJob::onLoginDone(KJob *job)
{
    if (job->error()) {
        setError(KJob::UserDefinedError);
        setErrorText("Failed to login: " + job->errorString());
        emitResult();
        return;
    }
    GetUserListJob *userListJob = new GetUserListJob(mSession, this);
    connect(userListJob, SIGNAL(result(KJob*)), this, SLOT(onUserListJobDone(KJob*)));
    userListJob->start();
}

void IMAPUserListJob::onUserListJobDone(KJob *job)
{
    if (job->error()) {
        setError(KJob::UserDefinedError);
        setErrorText("Failed to retrieve user list: " + job->errorString());
        emitResult();
        return;
    }
    GetUserListJob *userListJob = static_cast<GetUserListJob*>(job);
    mUserList = userListJob->getUserList();
    KIMAP::LogoutJob *logoutJob = new KIMAP::LogoutJob(mSession);
    connect(logoutJob, SIGNAL(result(KJob*)), this, SLOT(onLogoutDone(KJob*)));
    logoutJob->start();
}

void IMAPUserListJob::onLogoutDone(KJob *job)
{
    if (job->error()) {
        setError(KJob::UserDefinedError);
        setErrorText("Error during logout: " + job->errorString());
    }
    emitResult();
}

QStringList IMAPUserListJob::getUserList() const
{
    return mUserList;
}


IMAPSourceServer::IMAPSourceServer(QObject* parent)
:   SourceServer(parent),
    mSession(0),
    mEncryptionMode(KIMAP::LoginJob::TlsV1),
    mAuthenticationMode(KIMAP::LoginJob::Plain)
{

}

void IMAPSourceServer::setHost(const QString& host, qint16 port)
{
    mHost = host;
    mPort = port;
}

void IMAPSourceServer::setAdminCredentials(const QString& username, const QString& pw)
{
    mUsername = username;
    mPw = pw;
}

void IMAPSourceServer::setEncryption(KIMAP::LoginJob::EncryptionMode enc)
{
    mEncryptionMode = enc;
}

void IMAPSourceServer::setAuthentication(KIMAP::LoginJob::AuthenticationMode auth)
{
    mAuthenticationMode = auth;
}

QList<SourceAccount*> IMAPSourceServer::getSourceAccountsImpl(const QString& user)
{
    IMAPSourceAccount *account = new IMAPSourceAccount(this);
    account->prepareConnection(mHost, mPort, mUsername, user, mPw, mEncryptionMode, mAuthenticationMode);
    if (!mStatefile.isEmpty()) {
        account->setStatefile(StateFile(mStatefile, user));
    }
    return QList<SourceAccount*>() << account;
}

UserListJob *IMAPSourceServer::retrieveUserList()
{
    return new IMAPUserListJob(mHost, mPort, IMAPConnectionSettings(mUsername, mPw, mEncryptionMode, mAuthenticationMode), this);
}

//---------------------------------------------------------------------------

KolabSourceServer::KolabSourceServer(QObject* parent)
:   IMAPSourceServer(parent)
{

}

QList<SourceAccount*> KolabSourceServer::getSourceAccountsImpl(const QString& user)
{
    KolabSourceAccount *account = new KolabSourceAccount(this);
    account->prepareConnection(mHost, mPort, mUsername, user, mPw, mEncryptionMode, mAuthenticationMode);
    if (!mStatefile.isEmpty()) {
        account->setStatefile(StateFile(mStatefile, user));
    }
    return QList<SourceAccount*>() << account;
}

//---------------------------------------------------------------------

ExchangeIMAPSourceServer::ExchangeIMAPSourceServer(QObject* parent)
:   IMAPSourceServer(parent)
{

}

QList<SourceAccount*> ExchangeIMAPSourceServer::getSourceAccountsImpl(const QString& user)
{
    ExchangeIMAPSourceAccount *account = new ExchangeIMAPSourceAccount(this);
    account->prepareConnection(mHost, mPort, mUsername, user, mPw, mEncryptionMode, mAuthenticationMode);
    return QList<SourceAccount*>() << account;
}
