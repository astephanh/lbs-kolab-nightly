/*
 * Copyright (C) 2012  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef KOLABSERVER_H
#define KOLABSERVER_H
#include <QObject>
#include <QStringList>
#include <kolabobject.h>
#include <kimap/loginjob.h>

class KolabAccount;
class KolabServer: public QObject
{
    Q_OBJECT
public:
    explicit KolabServer(QObject* parent = 0);
    
    void setHost(const QString &host, qint16 port);
    void setAdminCredentials(const QString &username, const QString &pw);
    void setEncryption(KIMAP::LoginJob::EncryptionMode);
    void setAuthentication(KIMAP::LoginJob::AuthenticationMode);
    void addTargetUserForSource(const QString &sourceUser, const QString &targetUser);
    void setDryRun(bool);
    void setWipeTargetFolders(bool);
    void setRegextrans(const QStringList &);
    
    KolabAccount *getAccount(const QString &user);
    void setVersion(Kolab::Version);
private:
    QString mHost;
    int mPort;
    QString mUsername;
    QString mPw;
    KIMAP::LoginJob::EncryptionMode mEncryptionMode;
    KIMAP::LoginJob::AuthenticationMode mAuthenticationMode;
    bool mDryRun;
    bool mWipeTargetFolders;
    Kolab::Version mVersion;
    QHash<QString, QString> mTargetForSourceUser;
    QStringList mRegextrans;
};

#endif // KOLABSERVER_H
