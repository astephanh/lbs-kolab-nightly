/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "googlesourceserver.h"
#include "googlesourceaccount.h"
#include "imapsourceaccount.h"

#include <jobs/getuserlistjob.h>
#include <kimap/listjob.h>
#include <kimap/logoutjob.h>
#include <commonconversion.h>
#include <errorhandler.h>

GoogleSourceServer::GoogleSourceServer(QObject* parent)
:   SourceServer(parent),
    mPort(993),
    mEncryptionMode(KIMAP::LoginJob::AnySslVersion),
    mAuthenticationMode(KIMAP::LoginJob::ClearText)
{

}

void GoogleSourceServer::setHost(const QString& host, qint16 port)
{
    mHost = host;
    mPort = port;
}

void GoogleSourceServer::setAdminCredentials(const QString& username, const QString& pw)
{
    mUsername = username;
    mPw = pw;
}

void GoogleSourceServer::setEncryption(KIMAP::LoginJob::EncryptionMode enc)
{
    mEncryptionMode = enc;
}

void GoogleSourceServer::setAuthentication(KIMAP::LoginJob::AuthenticationMode auth)
{
    mAuthenticationMode = auth;
}

QList<SourceAccount*> GoogleSourceServer::getSourceAccountsImpl(const QString& user)
{
    QList <SourceAccount*> sourceAccounts;

    KGAPI2::AccountPtr sharedAccount;

    if (shouldMigrateType("contacts")) {
        GoogleContactsSourceAccount *contactsAccount = new GoogleContactsSourceAccount(this);
        contactsAccount->setUser(user);
        sourceAccounts << contactsAccount;
        sharedAccount = contactsAccount->account();
    }

    if (shouldMigrateType("events")) {
        GoogleCalendarSourceAccount *calendarAccount = new GoogleCalendarSourceAccount(this);
        if (sharedAccount) {
            calendarAccount->setAccount(sharedAccount);
        }
        calendarAccount->setUser(user);
        sourceAccounts << calendarAccount;
        sharedAccount = calendarAccount->account();
    }

    if (shouldMigrateType("tasks")) {
        GoogleTasksSourceAccount *tasksAccount = new GoogleTasksSourceAccount(this);
        if (sharedAccount) {
            tasksAccount->setAccount(sharedAccount);
        }
        tasksAccount->setUser(user);
        sourceAccounts << tasksAccount;
    }

    if (shouldMigrateType("mail")) {
        IMAPSourceAccount *imapAccount = new IMAPSourceAccount(this);
        imapAccount->prepareConnection(mHost, mPort, user, user, mPw, mEncryptionMode, mAuthenticationMode);
        imapAccount->setIgnoredFolders(ignoredFolders());
        sourceAccounts << imapAccount;
    }

    return sourceAccounts;
}