/*
 * Copyright (C) 2013  Christian Mollekopf <mollekopf@kolabsys.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "exchangesourceaccount.h"

#include <jobs/fetchmessagesjob.h>
#include <errorhandler.h>
#include <kabc/vcardconverter.h>
#include <kcalcore/memorycalendar.h>
#include <kcalcore/icalformat.h>

ExchangeIMAPSourceAccount::ExchangeIMAPSourceAccount(QObject* parent)
: IMAPSourceAccount(parent)
{

}

QPair<Kolab::ObjectType, KMime::Content*> ExchangeIMAPSourceAccount::getObjectType(const KMime::Message::Ptr &msg) const
{
    const QByteArray calendarType("text/calendar");
    const QByteArray vcardType("text/vcard");
    Q_FOREACH(KMime::Content *c, msg->contents()) {
        Debug() << c->contentType()->mimeType();
        if (c->contentType()->mimeType() == calendarType) {
            KCalCore::ICalFormat format;
            KCalCore::MemoryCalendar::Ptr calendar(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
            format.fromRawString(calendar, c->decodedContent());
            if (!calendar->events().isEmpty()) {
                return QPair<Kolab::ObjectType, KMime::Content*>(Kolab::EventObject, c);
            } else if (!calendar->todos().isEmpty()) {
                return QPair<Kolab::ObjectType, KMime::Content*>(Kolab::TodoObject, c);
            } else if (!calendar->journals().isEmpty()) {
                return QPair<Kolab::ObjectType, KMime::Content*>(Kolab::JournalObject, c);
            }
        }
        if (c->contentType()->mimeType() == vcardType) {
            return QPair<Kolab::ObjectType, KMime::Content*>(Kolab::ContactObject, c);
        }
    }
    return QPair<Kolab::ObjectType, KMime::Content*>(Kolab::InvalidObject, 0);
}

Kolab::FolderType ExchangeIMAPSourceAccount::getFolderType(const QString &folder)
{
    FetchMessagesJob *fetchJob = new FetchMessagesJob(folder, getSession(), this);
    //Theoretically one would be enough, but in case we have a couple of invalid ones...
    fetchJob->setMaxNumberOfMessagesToFetch(10);
    fetchJob->exec();
    Debug() << fetchJob->getMessages().size();
    QList<Object> messages;
    foreach (const KMime::Message::Ptr &msg, fetchJob->getMessages()) {
        Kolab::ObjectType type = getObjectType(msg).first;
        if (type == Kolab::EventObject) {
            return Kolab::EventType;
        }
        if (type == Kolab::TodoObject) {
            return Kolab::TaskType;
        }
        if (type == Kolab::JournalObject) {
            return Kolab::JournalType;
        }
        if (type == Kolab::ContactObject) {
            return Kolab::ContactType;
        }
    }
    return Kolab::MailType;
}

QPair<Kolab::FolderType, QString> ExchangeIMAPSourceAccount::translateFolder(const QString& folder)
{
    return QPair<Kolab::FolderType, QString>(getFolderType(folder), folder);
}

Object ExchangeIMAPSourceAccount::convertObject(const Object& object, const QString& /*folder*/) const
{
    KMime::Message::Ptr msg = object.object.value<KMime::Message::Ptr>();
    QPair<Kolab::ObjectType, KMime::Content*> type = getObjectType(msg);
    Debug() << type.first;
    if (type.first == Kolab::InvalidObject) {
        Object obj;
        obj.object = QVariant::fromValue(msg);
        obj.flags = object.flags;
        return obj;
    } else if (type.first == Kolab::EventObject || type.first == Kolab::TodoObject || type.first == Kolab::JournalObject) {
        const QByteArray content = type.second->decodedContent();
        Debug() << "Found incidence object: " << content;
        KCalCore::ICalFormat format;
        KCalCore::MemoryCalendar::Ptr calendar(new KCalCore::MemoryCalendar(KDateTime::Spec::UTC()));
        format.fromRawString(calendar, content);

        //We're simply assuming here that we never have different incidence types mixed in a folder
        foreach (const KCalCore::Incidence::Ptr &inc, calendar->incidences()) {
            Object obj;
            obj.object = QVariant::fromValue(inc);
            obj.flags = object.flags;
            if (!obj.object.isValid()) {
                Error() << "got empty message";
                continue;
            }
            return obj;
        }
    } else if (type.first == Kolab::ContactObject) {
        const QByteArray content = type.second->decodedContent();
        Debug() << "Found contact object: " << content;
        KABC::VCardConverter format;
        const KABC::Addressee addressee = format.parseVCard(content);

        Object obj;
        obj.object = QVariant::fromValue(addressee);
        obj.flags = object.flags;
        if (!obj.object.isValid()) {
            Error() << "got empty message";
            return object;
        }
        return obj;
    }
    return object;
}


